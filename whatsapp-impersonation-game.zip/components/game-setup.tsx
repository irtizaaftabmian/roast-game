"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Plus, X, Play } from "lucide-react"
import type { Player } from "@/app/page"

interface GameSetupProps {
  players: Player[]
  setPlayers: (players: Player[]) => void
  onStartGame: () => void
}

export default function GameSetup({ players, setPlayers, onStartGame }: GameSetupProps) {
  const [newPlayerName, setNewPlayerName] = useState("")
  const [newPlayerData, setNewPlayerData] = useState("")
  const [isAdding, setIsAdding] = useState(false)

  const addPlayer = () => {
    if (newPlayerName.trim() && newPlayerData.trim()) {
      const newPlayer: Player = {
        id: Date.now().toString(),
        name: newPlayerName.trim(),
        whatsappData: newPlayerData.trim(),
        avatar: `https://api.dicebear.com/7.x/avataaars/svg?seed=${newPlayerName}`,
        score: 0,
      }
      setPlayers([...players, newPlayer])
      setNewPlayerName("")
      setNewPlayerData("")
      setIsAdding(false)
    }
  }

  const removePlayer = (playerId: string) => {
    setPlayers(players.filter((p) => p.id !== playerId))
  }

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (file) {
      const reader = new FileReader()
      reader.onload = (e) => {
        const content = e.target?.result as string
        setNewPlayerData(content.slice(0, 2000))
      }
      reader.readAsText(file)
    }
  }

  return (
    <div className="space-y-8">
      {/* Add Player Form */}
      {isAdding ? (
        <Card className="bg-gray-900/50 border-gray-800 backdrop-blur-xl">
          <CardContent className="p-8">
            <div className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-3">Name</label>
                <Input
                  value={newPlayerName}
                  onChange={(e) => setNewPlayerName(e.target.value)}
                  placeholder="Enter player name"
                  className="bg-gray-800/50 border-gray-700 text-white placeholder:text-gray-500 h-12 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-300 mb-3">Upload Chat File</label>
                <Input
                  type="file"
                  accept=".txt,.csv"
                  onChange={handleFileUpload}
                  className="bg-gray-800/50 border-gray-700 text-white file:bg-blue-600 file:text-white file:border-0 file:rounded-lg file:px-4 file:py-2 file:mr-4 h-12 rounded-xl"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-300 mb-3">Or Paste Messages</label>
                <Textarea
                  value={newPlayerData}
                  onChange={(e) => setNewPlayerData(e.target.value)}
                  placeholder="Paste some sample messages from this person's chats..."
                  className="bg-gray-800/50 border-gray-700 text-white placeholder:text-gray-500 min-h-[120px] rounded-xl resize-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>

              <div className="flex gap-3">
                <Button
                  onClick={addPlayer}
                  disabled={!newPlayerName.trim() || !newPlayerData.trim()}
                  className="flex-1 bg-blue-600 hover:bg-blue-700 text-white h-12 rounded-xl font-medium transition-all duration-200"
                >
                  Add Player
                </Button>
                <Button
                  onClick={() => setIsAdding(false)}
                  variant="outline"
                  className="px-6 border-gray-700 text-gray-300 hover:bg-gray-800 h-12 rounded-xl"
                >
                  Cancel
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      ) : (
        <div className="text-center">
          <Button
            onClick={() => setIsAdding(true)}
            className="bg-gray-900/50 hover:bg-gray-800/50 border border-gray-800 text-white h-16 px-8 rounded-2xl font-medium transition-all duration-200 backdrop-blur-xl"
          >
            <Plus className="w-5 h-5 mr-3" />
            Add Player
          </Button>
        </div>
      )}

      {/* Players List */}
      {players.length > 0 && (
        <div className="space-y-4">
          <h3 className="text-lg font-semibold text-gray-300">Players ({players.length})</h3>
          <div className="grid gap-4">
            {players.map((player) => (
              <Card key={player.id} className="bg-gray-900/30 border-gray-800 backdrop-blur-xl">
                <CardContent className="p-6">
                  <div className="flex items-center gap-4">
                    <img
                      src={player.avatar || "/placeholder.svg"}
                      alt={player.name}
                      className="w-12 h-12 rounded-full ring-2 ring-gray-700"
                    />
                    <div className="flex-1">
                      <h4 className="font-medium text-white">{player.name}</h4>
                      <p className="text-sm text-gray-400">{player.whatsappData.length} characters loaded</p>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => removePlayer(player.id)}
                      className="text-gray-400 hover:text-red-400 hover:bg-red-400/10 rounded-lg"
                    >
                      <X className="w-4 h-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}

      {/* Start Game */}
      {players.length >= 2 && (
        <div className="text-center pt-8">
          <Button
            onClick={onStartGame}
            className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white h-16 px-12 rounded-2xl font-semibold text-lg transition-all duration-200 shadow-lg shadow-blue-500/25"
          >
            <Play className="w-6 h-6 mr-3" />
            Start Game
          </Button>
          <p className="text-gray-400 text-sm mt-4">{players.length} players ready to play</p>
        </div>
      )}

      {players.length > 0 && players.length < 2 && (
        <div className="text-center pt-8">
          <p className="text-gray-400">Add at least 2 players to start the game</p>
        </div>
      )}
    </div>
  )
}
