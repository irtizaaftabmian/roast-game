"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { ArrowLeft, MessageCircle, Shuffle, Copy, Loader2 } from "lucide-react"
import PersonManager from "@/components/person-manager"
import type { Person } from "@/app/page"

interface ImpersonatorAppProps {
  people: Person[]
  setPeople: (people: Person[]) => void
  onBack: () => void
}

export default function ImpersonatorApp({ people, setPeople, onBack }: ImpersonatorAppProps) {
  const [selectedPerson, setSelectedPerson] = useState<Person | null>(null)
  const [impersonation, setImpersonation] = useState("")
  const [isGenerating, setIsGenerating] = useState(false)

  const generateImpersonation = async () => {
    if (!selectedPerson) return

    setIsGenerating(true)

    try {
      const response = await fetch("/api/generate-impersonation", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          personName: selectedPerson.name,
          personData: selectedPerson.whatsappData,
          type: "impersonation",
        }),
      })

      const data = await response.json()

      if (data.success) {
        setImpersonation(data.result)
      } else {
        throw new Error(data.error || "Generation failed")
      }
    } catch (error) {
      console.error("Generation error:", error)
      setImpersonation("Sorry, couldn't generate an impersonation right now. Please try again!")
    } finally {
      setIsGenerating(false)
    }
  }

  const copyToClipboard = async () => {
    try {
      await navigator.clipboard.writeText(impersonation)
      // You could add a toast notification here
    } catch (error) {
      console.error("Copy failed:", error)
    }
  }

  return (
    <div className="space-y-8">
      {/* Header with Trolls */}
      <div className="flex items-center gap-4 relative">
        <div className="absolute -top-4 -left-8 text-3xl wiggle">🎭</div>
        <Button
          onClick={onBack}
          variant="ghost"
          className="text-gray-400 hover:text-white hover:bg-gray-800/50 rounded-xl"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back
        </Button>
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-xl bg-green-gradient">
            <MessageCircle className="w-5 h-5 text-white" />
          </div>
          <h1 className="text-3xl font-bold text-white">AI Impersonator</h1>
        </div>
        <div className="absolute -top-2 -right-4 text-2xl bounce-slow">🤖</div>
      </div>

      {/* Person Manager - No image upload for impersonator */}
      <PersonManager people={people} setPeople={setPeople} showImageUpload={false} />

      {people.length > 0 && (
        <>
          {/* Person Selection */}
          <Card className="bg-gray-900/50 border-green-700/30 shadow-xl backdrop-blur-sm">
            <CardContent className="p-6">
              <h3 className="text-lg font-semibold text-white mb-4">Choose someone to impersonate</h3>
              <div className="grid gap-3">
                {people.map((person) => (
                  <Button
                    key={person.id}
                    variant={selectedPerson?.id === person.id ? "default" : "outline"}
                    className={`p-4 h-auto justify-start rounded-xl transition-all duration-200 ${
                      selectedPerson?.id === person.id
                        ? "bg-green-600 hover:bg-green-700 text-white border-green-500"
                        : "bg-gray-800/30 hover:bg-gray-700/50 text-gray-200 border-gray-600/50"
                    }`}
                    onClick={() => setSelectedPerson(person)}
                  >
                    <div className="flex items-center gap-3">
                      <img
                        src={person.avatar || "/placeholder.svg"}
                        alt={person.name}
                        className="w-8 h-8 rounded-full"
                      />
                      <div className="text-left">
                        <div className="font-medium">{person.name}</div>
                        <div className="text-xs opacity-70">{person.whatsappData.length} characters loaded</div>
                      </div>
                    </div>
                  </Button>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Generation */}
          {selectedPerson && (
            <Card className="bg-gray-900/50 border-green-700/30 shadow-xl backdrop-blur-sm">
              <CardContent className="p-8">
                <div className="text-center space-y-6">
                  <div className="flex items-center justify-center gap-3">
                    <img
                      src={selectedPerson.avatar || "/placeholder.svg"}
                      alt={selectedPerson.name}
                      className="w-12 h-12 rounded-full ring-2 ring-green-500"
                    />
                    <h3 className="text-xl font-semibold text-white">Impersonating {selectedPerson.name}</h3>
                    <div className="text-xl">🎭</div>
                  </div>

                  <Button
                    onClick={generateImpersonation}
                    disabled={isGenerating}
                    className="bg-green-gradient hover:bg-green-gradient-dark text-white h-12 px-8 rounded-xl font-medium"
                  >
                    {isGenerating ? (
                      <div className="flex items-center gap-2">
                        <Loader2 className="w-4 h-4 animate-spin" />
                        Generating...
                      </div>
                    ) : (
                      <>
                        <Shuffle className="w-4 h-4 mr-2" />
                        Generate Impersonation
                      </>
                    )}
                  </Button>

                  {impersonation && (
                    <div className="space-y-4">
                      <Card className="bg-gradient-to-r from-green-900/40 to-emerald-800/40 border-green-500/50 backdrop-blur-sm">
                        <CardContent className="p-6">
                          <div className="flex items-start gap-3">
                            <img
                              src={selectedPerson.avatar || "/placeholder.svg"}
                              alt={selectedPerson.name}
                              className="w-8 h-8 rounded-full"
                            />
                            <div className="flex-1">
                              <div className="text-sm text-green-300 mb-1">{selectedPerson.name}</div>
                              <p className="text-white text-lg leading-relaxed">{impersonation}</p>
                            </div>
                          </div>
                        </CardContent>
                      </Card>

                      <div className="flex gap-3 justify-center">
                        <Button
                          onClick={generateImpersonation}
                          variant="outline"
                          className="border-green-500/50 text-green-300 hover:bg-green-900/30 rounded-xl"
                          disabled={isGenerating}
                        >
                          <Shuffle className="w-4 h-4 mr-2" />
                          Generate Another
                        </Button>
                        <Button
                          onClick={copyToClipboard}
                          variant="outline"
                          className="border-green-500/50 text-green-300 hover:bg-green-900/30 rounded-xl"
                        >
                          <Copy className="w-4 h-4 mr-2" />
                          Copy
                        </Button>
                      </div>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          )}
        </>
      )}
    </div>
  )
}
