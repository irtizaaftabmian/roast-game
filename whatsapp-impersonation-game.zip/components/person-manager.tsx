"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Plus, X, Upload, FileText, Loader2, ImageIcon, AlertCircle, CheckCircle, Briefcase, Link } from "lucide-react"
import type { Person } from "@/app/page"

interface PersonManagerProps {
  people: Person[]
  setPeople: (people: Person[]) => void
  showImageUpload?: boolean // New prop to show image upload for roasting
}

export default function PersonManager({ people, setPeople, showImageUpload = false }: PersonManagerProps) {
  const [newPersonName, setNewPersonName] = useState("")
  const [newPersonData, setNewPersonData] = useState("")
  const [newPersonImages, setNewPersonImages] = useState<string[]>([])
  const [newLinkedinUrl, setNewLinkedinUrl] = useState("")
  const [newLinkedinData, setNewLinkedinData] = useState("")
  const [isAdding, setIsAdding] = useState(false)
  const [isUploading, setIsUploading] = useState(false)
  const [uploadProgress, setUploadProgress] = useState("")
  const [uploadError, setUploadError] = useState("")

  const addPerson = () => {
    if (
      newPersonName.trim() &&
      (newPersonData.trim() || newPersonImages.length > 0 || newLinkedinData.trim() || newLinkedinUrl.trim())
    ) {
      const newPerson: Person = {
        id: Date.now().toString(),
        name: newPersonName.trim(),
        whatsappData: newPersonData.trim(),
        avatar: `https://api.dicebear.com/7.x/avataaars/svg?seed=${newPersonName}`,
        images: newPersonImages,
        linkedinUrl: newLinkedinUrl.trim(),
        linkedinData: newLinkedinData.trim(),
      }
      setPeople([...people, newPerson])
      setNewPersonName("")
      setNewPersonData("")
      setNewPersonImages([])
      setNewLinkedinUrl("")
      setNewLinkedinData("")
      setIsAdding(false)
      setUploadError("")
    }
  }

  const removePerson = (personId: string) => {
    setPeople(people.filter((p) => p.id !== personId))
  }

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (!file) return

    setIsUploading(true)
    setUploadProgress("Uploading file...")
    setUploadError("")

    try {
      // Upload file to Vercel Blob
      const uploadResponse = await fetch(`/api/upload?filename=${encodeURIComponent(file.name)}`, {
        method: "POST",
        body: file,
      })

      if (!uploadResponse.ok) {
        const errorData = await uploadResponse.json()
        throw new Error(errorData.error || "Upload failed")
      }

      const { url } = await uploadResponse.json()
      setUploadProgress("Processing chat data...")

      // Process the uploaded file
      const processResponse = await fetch("/api/process-chat", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          fileUrl: url,
          personName: newPersonName.trim(),
        }),
      })

      if (!processResponse.ok) {
        const errorData = await processResponse.json()
        throw new Error(errorData.error || "Processing failed")
      }

      const { data, characterCount } = await processResponse.json()
      setNewPersonData(data)
      setUploadProgress(`Processed ${characterCount} characters successfully!`)

      setTimeout(() => {
        setUploadProgress("")
      }, 2000)
    } catch (error) {
      console.error("File upload error:", error)
      setUploadError(error instanceof Error ? error.message : "Upload failed")
      setUploadProgress("")
    } finally {
      setIsUploading(false)
    }
  }

  const handleLinkedinPdfUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (!file) return

    // Validate file type
    if (!file.type.includes("pdf")) {
      setUploadError("Please upload a PDF file")
      return
    }

    setIsUploading(true)
    setUploadProgress("Uploading LinkedIn PDF...")
    setUploadError("")

    try {
      // Upload file to Vercel Blob
      const uploadResponse = await fetch(`/api/upload?filename=${encodeURIComponent(file.name)}`, {
        method: "POST",
        body: file,
      })

      if (!uploadResponse.ok) {
        const errorData = await uploadResponse.json()
        throw new Error(errorData.error || "Upload failed")
      }

      const { url } = await uploadResponse.json()
      setUploadProgress("Processing LinkedIn data...")

      // Process the uploaded LinkedIn PDF
      const processResponse = await fetch("/api/process-linkedin", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          fileUrl: url,
          personName: newPersonName.trim(),
        }),
      })

      if (!processResponse.ok) {
        const errorData = await processResponse.json()
        throw new Error(errorData.error || "Processing failed")
      }

      const { data, characterCount } = await processResponse.json()
      setNewLinkedinData(data)
      setUploadProgress(`Processed ${characterCount} characters of LinkedIn data!`)

      setTimeout(() => {
        setUploadProgress("")
      }, 2000)
    } catch (error) {
      console.error("LinkedIn PDF upload error:", error)
      setUploadError(error instanceof Error ? error.message : "LinkedIn upload failed")
      setUploadProgress("")
    } finally {
      setIsUploading(false)
    }
  }

  const handleLinkedinUrlProcess = async () => {
    if (!newLinkedinUrl.trim()) return

    setIsUploading(true)
    setUploadProgress("Processing LinkedIn URL...")
    setUploadError("")

    try {
      const processResponse = await fetch("/api/process-linkedin", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          linkedinUrl: newLinkedinUrl.trim(),
          personName: newPersonName.trim(),
        }),
      })

      if (!processResponse.ok) {
        const errorData = await processResponse.json()
        throw new Error(errorData.error || "Processing failed")
      }

      const { data } = await processResponse.json()
      setNewLinkedinData(data)
      setUploadProgress("LinkedIn URL processed!")

      setTimeout(() => {
        setUploadProgress("")
      }, 2000)
    } catch (error) {
      console.error("LinkedIn URL processing error:", error)
      setUploadError(error instanceof Error ? error.message : "LinkedIn URL processing failed")
      setUploadProgress("")
    } finally {
      setIsUploading(false)
    }
  }

  const handleImageUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files
    if (!files || files.length === 0) return

    setIsUploading(true)
    setUploadProgress("Uploading images...")
    setUploadError("")

    try {
      const uploadPromises = Array.from(files).map(async (file, index) => {
        // Validate file type
        if (!file.type.startsWith("image/")) {
          throw new Error(`File ${file.name} is not an image`)
        }

        // Validate file size (max 10MB)
        if (file.size > 10 * 1024 * 1024) {
          throw new Error(`File ${file.name} is too large (max 10MB)`)
        }

        console.log(`Uploading image ${index + 1}:`, file.name, file.type, file.size)

        const uploadResponse = await fetch(`/api/upload?filename=${encodeURIComponent(file.name)}`, {
          method: "POST",
          body: file,
        })

        if (!uploadResponse.ok) {
          const errorData = await uploadResponse.json()
          throw new Error(`Failed to upload ${file.name}: ${errorData.error}`)
        }

        const { url } = await uploadResponse.json()
        console.log(`Image ${index + 1} uploaded successfully:`, url)
        return url
      })

      const uploadedUrls = await Promise.all(uploadPromises)
      setNewPersonImages([...newPersonImages, ...uploadedUrls])
      setUploadProgress(`Uploaded ${uploadedUrls.length} image(s) successfully!`)

      setTimeout(() => {
        setUploadProgress("")
      }, 2000)
    } catch (error) {
      console.error("Image upload error:", error)
      setUploadError(error instanceof Error ? error.message : "Image upload failed")
      setUploadProgress("")
    } finally {
      setIsUploading(false)
    }
  }

  const removeImage = (imageUrl: string) => {
    setNewPersonImages(newPersonImages.filter((url) => url !== imageUrl))
  }

  return (
    <div className="space-y-6">
      {/* Add Person Form */}
      {isAdding ? (
        <Card className="bg-gray-900/50 border-green-700/30 shadow-xl backdrop-blur-sm">
          <CardContent className="p-6">
            <div className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">Name</label>
                <Input
                  value={newPersonName}
                  onChange={(e) => setNewPersonName(e.target.value)}
                  placeholder="Enter person's name"
                  className="bg-gray-800/50 border-gray-600/50 text-white placeholder:text-gray-400 h-10 rounded-lg"
                />
              </div>

              {showImageUpload && (
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">Upload Photos/Selfies 📸</label>
                  <div className="space-y-3">
                    <Input
                      type="file"
                      accept="image/*"
                      multiple
                      onChange={handleImageUpload}
                      disabled={isUploading}
                      className="bg-gray-800/50 border-gray-600/50 text-white file:bg-green-600 file:text-white file:border-0 file:rounded file:px-3 file:py-1 file:mr-3 h-10 rounded-lg"
                    />

                    {newPersonImages.length > 0 && (
                      <div className="grid grid-cols-3 gap-2">
                        {newPersonImages.map((imageUrl, index) => (
                          <div key={index} className="relative group">
                            <img
                              src={imageUrl || "/placeholder.svg"}
                              alt={`Upload ${index + 1}`}
                              className="w-full h-20 object-cover rounded-lg border-2 border-gray-600/50"
                              onError={(e) => {
                                console.error("Image failed to load:", imageUrl)
                                e.currentTarget.src = "/placeholder.svg"
                              }}
                            />
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => removeImage(imageUrl)}
                              className="absolute -top-2 -right-2 w-6 h-6 p-0 bg-red-500 hover:bg-red-600 text-white rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                            >
                              <X className="w-3 h-3" />
                            </Button>
                          </div>
                        ))}
                      </div>
                    )}

                    <div className="text-xs text-gray-400 space-y-1">
                      <p>
                        📷 <strong>Perfect for roasting:</strong> Selfies, group photos, funny moments
                      </p>
                    </div>
                  </div>
                </div>
              )}

              {/* LinkedIn Section */}
              {showImageUpload && (
                <div className="border-t border-gray-700/50 pt-6">
                  <label className="block text-sm font-medium text-gray-300 mb-3 flex items-center gap-2">
                    <Briefcase className="w-4 h-4" />
                    LinkedIn Data 💼
                  </label>

                  <div className="space-y-4">
                    {/* LinkedIn URL Input */}
                    <div>
                      <label className="block text-xs text-gray-400 mb-2">LinkedIn Profile URL</label>
                      <div className="flex gap-2">
                        <Input
                          value={newLinkedinUrl}
                          onChange={(e) => setNewLinkedinUrl(e.target.value)}
                          placeholder="https://linkedin.com/in/username"
                          className="bg-gray-800/50 border-gray-600/50 text-white placeholder:text-gray-400 h-10 rounded-lg flex-1"
                        />
                        <Button
                          onClick={handleLinkedinUrlProcess}
                          disabled={!newLinkedinUrl.trim() || isUploading}
                          className="bg-blue-600 hover:bg-blue-700 text-white px-4 h-10 rounded-lg"
                        >
                          <Link className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>

                    {/* OR Divider */}
                    <div className="flex items-center gap-3">
                      <div className="flex-1 h-px bg-gray-600/50"></div>
                      <span className="text-xs text-gray-500">OR</span>
                      <div className="flex-1 h-px bg-gray-600/50"></div>
                    </div>

                    {/* LinkedIn PDF Upload */}
                    <div>
                      <label className="block text-xs text-gray-400 mb-2">Upload LinkedIn PDF Export</label>
                      <Input
                        type="file"
                        accept=".pdf"
                        onChange={handleLinkedinPdfUpload}
                        disabled={isUploading}
                        className="bg-gray-800/50 border-gray-600/50 text-white file:bg-blue-600 file:text-white file:border-0 file:rounded file:px-3 file:py-1 file:mr-3 h-10 rounded-lg"
                      />
                    </div>

                    {/* LinkedIn Data Preview */}
                    {newLinkedinData && (
                      <div className="bg-blue-900/20 border border-blue-600/30 rounded-lg p-3">
                        <div className="flex items-center gap-2 mb-2">
                          <Briefcase className="w-4 h-4 text-blue-400" />
                          <span className="text-sm text-blue-300">LinkedIn Data Loaded</span>
                        </div>
                        <p className="text-xs text-gray-400 line-clamp-3">{newLinkedinData.slice(0, 150)}...</p>
                      </div>
                    )}

                    <div className="text-xs text-gray-400 space-y-1">
                      <p>
                        💼 <strong>LinkedIn roasting material:</strong>
                      </p>
                      <p>• Job titles, company names, buzzwords</p>
                      <p>• Professional achievements and skills</p>
                      <p>• Perfect for career-based roasts! 😈</p>
                    </div>
                  </div>
                </div>
              )}

              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">Upload WhatsApp Chat Export</label>
                <div className="space-y-3">
                  <Input
                    type="file"
                    accept=".txt,.csv"
                    onChange={handleFileUpload}
                    disabled={isUploading}
                    className="bg-gray-800/50 border-gray-600/50 text-white file:bg-green-600 file:text-white file:border-0 file:rounded file:px-3 file:py-1 file:mr-3 h-10 rounded-lg"
                  />

                  <div className="text-xs text-gray-400 space-y-1">
                    <p>
                      💡 <strong>How to export WhatsApp chats:</strong>
                    </p>
                    <p>• Open WhatsApp → Chat → Menu (⋮) → More → Export chat → Without media</p>
                    <p>• Or paste sample messages below</p>
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">Or Paste Messages</label>
                <Textarea
                  value={newPersonData}
                  onChange={(e) => setNewPersonData(e.target.value)}
                  placeholder="Paste some sample messages from this person's chats..."
                  className="bg-gray-800/50 border-gray-600/50 text-white placeholder:text-gray-400 min-h-[100px] rounded-lg resize-none"
                />
              </div>

              {/* Upload Progress/Error */}
              {uploadProgress && (
                <div className="flex items-center gap-2 text-sm">
                  {isUploading ? (
                    <Loader2 className="w-4 h-4 animate-spin text-green-400" />
                  ) : (
                    <CheckCircle className="w-4 h-4 text-green-400" />
                  )}
                  <span className={isUploading ? "text-green-400" : "text-green-300"}>{uploadProgress}</span>
                </div>
              )}

              {uploadError && (
                <div className="flex items-center gap-2 text-sm text-red-400">
                  <AlertCircle className="w-4 h-4" />
                  <span>{uploadError}</span>
                </div>
              )}

              <div className="flex gap-3">
                <Button
                  onClick={addPerson}
                  disabled={
                    !newPersonName.trim() ||
                    (!newPersonData.trim() &&
                      newPersonImages.length === 0 &&
                      !newLinkedinData.trim() &&
                      !newLinkedinUrl.trim()) ||
                    isUploading
                  }
                  className="flex-1 bg-green-gradient hover:bg-green-gradient-dark text-white h-10 rounded-lg"
                >
                  <Upload className="w-4 h-4 mr-2" />
                  Add Person
                </Button>
                <Button
                  onClick={() => {
                    setIsAdding(false)
                    setNewPersonName("")
                    setNewPersonData("")
                    setNewPersonImages([])
                    setNewLinkedinUrl("")
                    setNewLinkedinData("")
                    setUploadProgress("")
                    setUploadError("")
                  }}
                  variant="outline"
                  className="px-4 border-gray-600/50 text-gray-300 hover:bg-gray-800/50 h-10 rounded-lg"
                  disabled={isUploading}
                >
                  Cancel
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      ) : (
        <div className="text-center relative">
          <div className="absolute -top-2 -left-4 text-2xl wiggle">👤</div>
          <Button
            onClick={() => setIsAdding(true)}
            className="bg-gray-800/50 hover:bg-gray-700/60 border border-gray-600/50 text-gray-200 h-12 px-6 rounded-xl"
          >
            <Plus className="w-4 h-4 mr-2" />
            {showImageUpload ? "Add Person + Data" : "Add Person"}
          </Button>
          <div className="absolute -top-2 -right-4 text-2xl bounce-slow">{showImageUpload ? "💼" : "➕"}</div>
        </div>
      )}

      {/* People List */}
      {people.length > 0 && (
        <div className="space-y-3">
          <h3 className="text-sm font-medium text-gray-300">Added People ({people.length})</h3>
          <div className="grid gap-3">
            {people.map((person) => (
              <Card key={person.id} className="bg-gray-900/30 border-gray-700/30 shadow-lg backdrop-blur-sm">
                <CardContent className="p-4">
                  <div className="flex items-center gap-3">
                    <img src={person.avatar || "/placeholder.svg"} alt={person.name} className="w-8 h-8 rounded-full" />
                    <div className="flex-1">
                      <h4 className="font-medium text-white text-sm">{person.name}</h4>
                      <div className="flex items-center gap-4 text-xs text-gray-400">
                        {person.whatsappData && (
                          <div className="flex items-center gap-1">
                            <FileText className="w-3 h-3" />
                            <span>{person.whatsappData.length} chars</span>
                          </div>
                        )}
                        {person.images && person.images.length > 0 && (
                          <div className="flex items-center gap-1">
                            <ImageIcon className="w-3 h-3" />
                            <span>
                              {person.images.length} photo{person.images.length !== 1 ? "s" : ""}
                            </span>
                          </div>
                        )}
                        {(person.linkedinData || person.linkedinUrl) && (
                          <div className="flex items-center gap-1">
                            <Briefcase className="w-3 h-3" />
                            <span>LinkedIn</span>
                          </div>
                        )}
                      </div>
                    </div>
                    {person.images && person.images.length > 0 && (
                      <div className="flex -space-x-1">
                        {person.images.slice(0, 3).map((imageUrl, index) => (
                          <img
                            key={index}
                            src={imageUrl || "/placeholder.svg"}
                            alt={`${person.name} ${index + 1}`}
                            className="w-6 h-6 rounded-full border border-gray-600 object-cover"
                            onError={(e) => {
                              console.error("Thumbnail failed to load:", imageUrl)
                              e.currentTarget.src = "/placeholder.svg"
                            }}
                          />
                        ))}
                        {person.images.length > 3 && (
                          <div className="w-6 h-6 rounded-full bg-gray-700 border border-gray-600 flex items-center justify-center text-xs text-gray-300">
                            +{person.images.length - 3}
                          </div>
                        )}
                      </div>
                    )}
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => removePerson(person.id)}
                      className="text-gray-500 hover:text-red-400 hover:bg-red-900/20 rounded-lg p-1"
                    >
                      <X className="w-3 h-3" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}

      {/* Instructions */}
      {people.length === 0 && !isAdding && (
        <Card className="bg-gray-900/30 border-gray-700/30 shadow-xl backdrop-blur-sm">
          <CardContent className="p-6 text-center">
            <div className="w-12 h-12 text-gray-500 mx-auto mb-4">
              {showImageUpload ? <Briefcase className="w-12 h-12" /> : <FileText className="w-12 h-12" />}
            </div>
            <h3 className="text-lg font-semibold text-white mb-2">No people added yet</h3>
            <p className="text-gray-400 text-sm mb-4">
              {showImageUpload
                ? "Add people with photos, LinkedIn data, and chat history for ultimate roasting power"
                : "Add people by uploading their WhatsApp chat exports or pasting sample messages"}
            </p>
            <div className="text-xs text-gray-500 space-y-1">
              {showImageUpload ? (
                <>
                  <p>📸 Upload selfies and photos for visual roasts</p>
                  <p>💼 Add LinkedIn profiles for professional roasts</p>
                  <p>💬 Include chat data for personality-based burns</p>
                  <p>🔥 AI combines all data for devastating roasts</p>
                </>
              ) : (
                <>
                  <p>📱 Export from WhatsApp: Chat → Menu → More → Export chat</p>
                  <p>🔒 All data is processed securely and not stored permanently</p>
                </>
              )}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
