"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Separator } from "@/components/ui/separator"
import { Plus, Users } from "lucide-react"

interface JoinRoomProps {
  onCreateRoom: (hostName: string) => void
  onJoinRoom: (roomCode: string, playerName: string) => void
}

export default function JoinRoom({ onCreateRoom, onJoinRoom }: JoinRoomProps) {
  const [hostName, setHostName] = useState("")
  const [joinName, setJoinName] = useState("")
  const [roomCode, setRoomCode] = useState("")

  const handleCreateRoom = () => {
    if (hostName.trim()) {
      onCreateRoom(hostName.trim())
    }
  }

  const handleJoinRoom = () => {
    if (joinName.trim() && roomCode.trim()) {
      onJoinRoom(roomCode.trim().toUpperCase(), joinName.trim())
    }
  }

  return (
    <div className="max-w-4xl mx-auto">
      <div className="grid md:grid-cols-2 gap-8">
        {/* Create Room */}
        <Card className="bg-white/10 backdrop-blur-sm border-white/20">
          <CardHeader className="text-center">
            <Plus className="w-12 h-12 text-green-400 mx-auto mb-2" />
            <CardTitle className="text-white">Create New Game</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="hostName" className="text-white">
                Your Name
              </Label>
              <Input
                id="hostName"
                value={hostName}
                onChange={(e) => setHostName(e.target.value)}
                placeholder="Enter your name"
                className="bg-white/20 border-white/30 text-white placeholder:text-white/60"
                onKeyPress={(e) => e.key === "Enter" && handleCreateRoom()}
              />
            </div>

            <Button
              onClick={handleCreateRoom}
              disabled={!hostName.trim()}
              className="w-full bg-green-600 hover:bg-green-700 text-white"
            >
              <Plus className="w-4 h-4 mr-2" />
              Create Room
            </Button>

            <div className="text-center text-sm text-purple-200">You'll be the host and can control the game</div>
          </CardContent>
        </Card>

        {/* Join Room */}
        <Card className="bg-white/10 backdrop-blur-sm border-white/20">
          <CardHeader className="text-center">
            <Users className="w-12 h-12 text-blue-400 mx-auto mb-2" />
            <CardTitle className="text-white">Join Existing Game</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="joinName" className="text-white">
                Your Name
              </Label>
              <Input
                id="joinName"
                value={joinName}
                onChange={(e) => setJoinName(e.target.value)}
                placeholder="Enter your name"
                className="bg-white/20 border-white/30 text-white placeholder:text-white/60"
              />
            </div>

            <div>
              <Label htmlFor="roomCode" className="text-white">
                Room Code
              </Label>
              <Input
                id="roomCode"
                value={roomCode}
                onChange={(e) => setRoomCode(e.target.value.toUpperCase())}
                placeholder="Enter 6-letter room code"
                className="bg-white/20 border-white/30 text-white placeholder:text-white/60 font-mono text-center text-lg"
                maxLength={6}
                onKeyPress={(e) => e.key === "Enter" && handleJoinRoom()}
              />
            </div>

            <Button
              onClick={handleJoinRoom}
              disabled={!joinName.trim() || !roomCode.trim() || roomCode.length !== 6}
              className="w-full bg-blue-600 hover:bg-blue-700 text-white"
            >
              <Users className="w-4 h-4 mr-2" />
              Join Room
            </Button>

            <div className="text-center text-sm text-purple-200">Ask the host for the room code</div>
          </CardContent>
        </Card>
      </div>

      <div className="mt-8 text-center">
        <Separator className="bg-white/20 mb-4" />
        <p className="text-purple-200 text-sm">💡 Tip: All players need to be in the same room to play together!</p>
      </div>
    </div>
  )
}
