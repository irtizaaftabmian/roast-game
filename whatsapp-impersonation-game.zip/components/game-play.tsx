"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { MessageCircle, Zap, Trophy, Clock, ArrowRight } from "lucide-react"
import type { Player } from "@/app/page"

interface GamePlayProps {
  players: Player[]
  setPlayers: (players: Player[]) => void
  currentRound: number
  setCurrentRound: (round: number) => void
  onEndGame: () => void
}

type GameMode = "question" | "roast" | "voice"
type RoundState = "loading" | "guessing" | "results"

const TOTAL_ROUNDS = 6
const ROUND_TIME = 30

export default function GamePlay({ players, setPlayers, currentRound, setCurrentRound, onEndGame }: GamePlayProps) {
  const [roundState, setRoundState] = useState<RoundState>("loading")
  const [currentMode, setCurrentMode] = useState<GameMode>("question")
  const [impersonatedPlayer, setImpersonatedPlayer] = useState<Player | null>(null)
  const [aiResponse, setAiResponse] = useState("")
  const [timeLeft, setTimeLeft] = useState(ROUND_TIME)
  const [selectedGuess, setSelectedGuess] = useState<string | null>(null)

  useEffect(() => {
    if (currentRound < TOTAL_ROUNDS) {
      startNewRound()
    } else {
      onEndGame()
    }
  }, [currentRound])

  useEffect(() => {
    let timer: NodeJS.Timeout
    if (roundState === "guessing" && timeLeft > 0) {
      timer = setTimeout(() => setTimeLeft(timeLeft - 1), 1000)
    } else if (timeLeft === 0 && roundState === "guessing") {
      showResults()
    }
    return () => clearTimeout(timer)
  }, [timeLeft, roundState])

  const startNewRound = () => {
    const modes: GameMode[] = ["question", "roast", "voice"]
    const mode = modes[currentRound % 3]
    const randomPlayer = players[Math.floor(Math.random() * players.length)]

    setCurrentMode(mode)
    setImpersonatedPlayer(randomPlayer)
    setRoundState("loading")
    setTimeLeft(ROUND_TIME)
    setSelectedGuess(null)

    generateAIResponse(randomPlayer, mode)
  }

  const generateAIResponse = async (player: Player, mode: GameMode) => {
    const responses = {
      question: [
        `OMG you guys won't believe what just happened to me 😭`,
        `Anyone else think pineapple on pizza is actually fire? Don't @ me 🍕`,
        `Just binged that new series and now I don't know what to do with my life`,
        `Why do I always pick the slowest line at literally every store? 🙄`,
        `Coffee or tea? This will determine if we can be friends lol`,
        `Can someone explain why I'm like this? Asking for a friend... the friend is me`,
      ],
      roast: [
        `Some people really think they invented confidence huh? 💅`,
        `Imagine being that wrong but that loud about it... couldn't be me`,
        `The audacity some people have is honestly inspiring at this point`,
        `Not everyone can pull off that energy but hey, you do you bestie ✨`,
        `When someone thinks they're the main character but they're clearly just comic relief`,
      ],
      voice: [
        `*dramatically sighs* "This is literally the most important thing that has EVER happened"`,
        `*in their typical whiny voice* "Why does this stuff always happen to meeee?"`,
        `*excited screaming* "GUYS GUYS GUYS you need to hear this RIGHT NOW"`,
        `*deadpan delivery* "Well that was... something. Anyway..."`,
        `*overly enthusiastic* "OH MY GOD this is going to be AMAZING!"`,
      ],
    }

    const randomResponse = responses[mode][Math.floor(Math.random() * responses[mode].length)]

    setTimeout(() => {
      setAiResponse(randomResponse)
      setRoundState("guessing")
    }, 2500)
  }

  const makeGuess = (playerId: string) => {
    setSelectedGuess(playerId)
  }

  const showResults = () => {
    setRoundState("results")

    if (selectedGuess === impersonatedPlayer?.id) {
      const updatedPlayers = players.map((player) =>
        player.id === selectedGuess ? { ...player, score: player.score + 100 } : player,
      )
      setPlayers(updatedPlayers)
    }
  }

  const nextRound = () => {
    setCurrentRound(currentRound + 1)
  }

  const getModeInfo = (mode: GameMode) => {
    switch (mode) {
      case "question":
        return { icon: MessageCircle, title: "Question Round", color: "from-blue-500 to-cyan-500" }
      case "roast":
        return { icon: Zap, title: "Roast Round", color: "from-orange-500 to-red-500" }
      case "voice":
        return { icon: Trophy, title: "Voice Round", color: "from-purple-500 to-pink-500" }
    }
  }

  const modeInfo = getModeInfo(currentMode)
  const Icon = modeInfo.icon

  return (
    <div className="space-y-8">
      {/* Round Header */}
      <Card className="bg-gray-900/30 border-gray-800 backdrop-blur-xl">
        <CardContent className="p-8">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-4">
              <div className={`p-3 rounded-2xl bg-gradient-to-r ${modeInfo.color}`}>
                <Icon className="w-6 h-6 text-white" />
              </div>
              <div>
                <h2 className="text-2xl font-bold text-white">{modeInfo.title}</h2>
                <p className="text-gray-400">
                  Round {currentRound + 1} of {TOTAL_ROUNDS}
                </p>
              </div>
            </div>
            {roundState === "guessing" && (
              <div className="flex items-center gap-2 bg-gray-800/50 px-4 py-2 rounded-xl">
                <Clock className="w-4 h-4 text-blue-400" />
                <span className="text-white font-mono text-lg">{timeLeft}s</span>
              </div>
            )}
          </div>
          <Progress value={(currentRound / TOTAL_ROUNDS) * 100} className="h-2 bg-gray-800" />
        </CardContent>
      </Card>

      {/* Game Content */}
      {roundState === "loading" && (
        <Card className="bg-gray-900/30 border-gray-800 backdrop-blur-xl">
          <CardContent className="p-12 text-center">
            <div className="animate-pulse space-y-6">
              <div className="w-16 h-16 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full mx-auto flex items-center justify-center">
                <span className="text-2xl">🤖</span>
              </div>
              <div>
                <h3 className="text-2xl font-semibold text-white mb-2">AI is thinking...</h3>
                <p className="text-gray-400">Analyzing chat patterns and generating response</p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {roundState === "guessing" && (
        <div className="space-y-8">
          <Card className="bg-gray-900/30 border-gray-800 backdrop-blur-xl">
            <CardContent className="p-8">
              <h3 className="text-xl font-semibold text-white mb-6">Who said this?</h3>
              <div className="bg-gradient-to-r from-gray-800/50 to-gray-700/50 rounded-2xl p-6 mb-8">
                <p className="text-lg text-white leading-relaxed italic">"{aiResponse}"</p>
              </div>

              <div className="grid gap-4">
                {players.map((player) => (
                  <Button
                    key={player.id}
                    variant={selectedGuess === player.id ? "default" : "outline"}
                    className={`p-6 h-auto justify-start rounded-2xl transition-all duration-200 ${
                      selectedGuess === player.id
                        ? "bg-blue-600 hover:bg-blue-700 text-white border-blue-500"
                        : "bg-gray-800/30 hover:bg-gray-700/50 text-white border-gray-700"
                    }`}
                    onClick={() => makeGuess(player.id)}
                  >
                    <div className="flex items-center gap-4">
                      <img
                        src={player.avatar || "/placeholder.svg"}
                        alt={player.name}
                        className="w-10 h-10 rounded-full"
                      />
                      <span className="text-lg font-medium">{player.name}</span>
                    </div>
                  </Button>
                ))}
              </div>

              {selectedGuess && (
                <div className="text-center mt-8">
                  <Button
                    onClick={showResults}
                    className="bg-green-600 hover:bg-green-700 text-white h-12 px-8 rounded-xl font-medium"
                  >
                    Lock in Answer
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      )}

      {roundState === "results" && (
        <div className="space-y-8">
          <Card className="bg-gray-900/30 border-gray-800 backdrop-blur-xl">
            <CardContent className="p-8 text-center">
              <div className="mb-8">
                {selectedGuess === impersonatedPlayer?.id ? (
                  <div className="space-y-4">
                    <div className="text-6xl">🎉</div>
                    <h3 className="text-3xl font-bold text-green-400">Correct!</h3>
                    <div className="bg-green-500/20 border border-green-500/30 rounded-2xl px-6 py-3 inline-block">
                      <span className="text-green-300 font-semibold text-lg">+100 Points</span>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-4">
                    <div className="text-6xl">😅</div>
                    <h3 className="text-3xl font-bold text-red-400">Wrong!</h3>
                  </div>
                )}
              </div>

              <div className="space-y-6">
                <p className="text-gray-400">The correct answer was:</p>
                <div className="flex items-center justify-center gap-4">
                  <img
                    src={impersonatedPlayer?.avatar || "/placeholder.svg"}
                    alt={impersonatedPlayer?.name}
                    className="w-16 h-16 rounded-full ring-4 ring-blue-500"
                  />
                  <h4 className="text-3xl font-bold text-white">{impersonatedPlayer?.name}</h4>
                </div>

                <div className="bg-gray-800/50 rounded-2xl p-6 max-w-2xl mx-auto">
                  <p className="text-white italic text-lg">"{aiResponse}"</p>
                </div>
              </div>

              <Button
                onClick={nextRound}
                className="mt-8 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white h-14 px-8 rounded-2xl font-semibold text-lg"
              >
                {currentRound + 1 < TOTAL_ROUNDS ? (
                  <>
                    Next Round
                    <ArrowRight className="w-5 h-5 ml-2" />
                  </>
                ) : (
                  "View Results"
                )}
              </Button>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Scoreboard */}
      <Card className="bg-gray-900/30 border-gray-800 backdrop-blur-xl">
        <CardContent className="p-6">
          <h3 className="text-lg font-semibold text-white mb-4">Current Scores</h3>
          <div className="space-y-3">
            {players
              .sort((a, b) => b.score - a.score)
              .map((player, index) => (
                <div key={player.id} className="flex items-center gap-4 p-3 bg-gray-800/30 rounded-xl">
                  <div className="text-gray-400 font-bold text-lg w-8">#{index + 1}</div>
                  <img src={player.avatar || "/placeholder.svg"} alt={player.name} className="w-8 h-8 rounded-full" />
                  <span className="flex-1 text-white font-medium">{player.name}</span>
                  <div className="bg-blue-600/20 text-blue-300 px-3 py-1 rounded-lg font-semibold">
                    {player.score} pts
                  </div>
                </div>
              ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
