"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import {
  ArrowLeft,
  Zap,
  Flame,
  Copy,
  Share,
  Loader2,
  Camera,
  MessageCircle,
  AlertCircle,
  CheckCircle,
  Briefcase,
  Volume2,
  Pause,
} from "lucide-react"
import PersonManager from "@/components/person-manager"
import type { Person } from "@/app/page"

interface RoastingAppProps {
  people: Person[]
  setPeople: (people: Person[]) => void
  onBack: () => void
}

type RoastIntensity = "mild" | "medium" | "savage"
type RoastType = "text" | "visual" | "combined"

export default function RoastingApp({ people, setPeople, onBack }: RoastingAppProps) {
  const [selectedPerson, setSelectedPerson] = useState<Person | null>(null)
  const [roastIntensity, set_roastIntensity] = useState<RoastIntensity>("medium")
  const [roastType, setRoastType] = useState<RoastType>("combined")
  const [roast, setRoast] = useState("")
  const [isGenerating, setIsGenerating] = useState(false)
  const [error, setError] = useState("")

  const [isPlaying, setIsPlaying] = useState(false)
  const [speechSupported, setSpeechSupported] = useState(false)
  const [currentUtterance, setCurrentUtterance] = useState<SpeechSynthesisUtterance | null>(null)

  // ElevenLabs state
  const [audioUrl, setAudioUrl] = useState<string | null>(null)
  const [audioElement, setAudioElement] = useState<HTMLAudioElement | null>(null)
  const [isGeneratingAudio, setIsGeneratingAudio] = useState(false)
  const [audioError, setAudioError] = useState("")

  useEffect(() => {
    // Check if speech synthesis is supported (fallback)
    if (typeof window !== "undefined" && "speechSynthesis" in window) {
      setSpeechSupported(true)
    }
  }, [])

  // Auto-generate ElevenLabs audio when roast is generated
  useEffect(() => {
    if (roast && !audioUrl && !isGeneratingAudio) {
      console.log("🎤 Auto-generating ElevenLabs audio for new roast...")
      generateElevenLabsAudio()
    }
  }, [roast]) // Trigger when roast changes

  // Generate ElevenLabs audio
  const generateElevenLabsAudio = async () => {
    if (!roast) {
      console.warn("No roast text available for audio generation")
      return
    }

    setIsGeneratingAudio(true)
    setAudioError("")

    try {
      console.log("🎤 Generating ElevenLabs audio...")

      const response = await fetch("/api/elevenlabs-tts", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          text: roast,
          voiceId: "JBFqnCBsd6RMkjVDRZzb",
        }),
      })

      if (!response.ok) {
        let errorMessage = `HTTP ${response.status}`
        try {
          const errorData = await response.json()
          errorMessage = errorData.error || errorMessage
        } catch {
          errorMessage = (await response.text()) || errorMessage
        }
        throw new Error(errorMessage)
      }

      // Verify content type
      const contentType = response.headers.get("Content-Type") || ""
      if (!contentType.includes("audio")) {
        throw new Error(`Expected audio, got: ${contentType}`)
      }

      // Create audio blob with explicit type
      const arrayBuffer = await response.arrayBuffer()
      if (arrayBuffer.byteLength === 0) {
        throw new Error("Received empty audio data")
      }

      const audioBlob = new Blob([arrayBuffer], { type: "audio/mpeg" })
      const url = URL.createObjectURL(audioBlob)

      // Clean up previous audio URL
      if (audioUrl) {
        URL.revokeObjectURL(audioUrl)
      }

      setAudioUrl(url)
      console.log("✅ ElevenLabs audio generated successfully, blob size:", audioBlob.size, "bytes")
    } catch (error) {
      console.error("ElevenLabs generation error:", error)
      const errorMsg = error instanceof Error ? error.message : "Failed to generate audio"
      setAudioError(errorMsg)

      // Don't auto-fallback to browser TTS, let user choose
      console.log("Audio generation failed, user can use browser TTS as fallback")
    } finally {
      setIsGeneratingAudio(false)
    }
  }

  // Play ElevenLabs audio
  const playElevenLabsAudio = async () => {
    if (!audioUrl) {
      console.log("No audio URL available, generating...")
      await generateElevenLabsAudio()
      return
    }

    try {
      // Stop any currently playing audio
      if (audioElement) {
        audioElement.pause()
        audioElement.currentTime = 0
        setAudioElement(null)
      }

      // Stop browser TTS if playing
      if (currentUtterance) {
        window.speechSynthesis.cancel()
        setCurrentUtterance(null)
      }

      console.log("🔊 Playing ElevenLabs audio...")
      const audio = new Audio()

      // Set up event listeners before setting src
      audio.addEventListener("loadstart", () => {
        console.log("Audio loading started...")
      })

      audio.addEventListener("canplay", () => {
        console.log("Audio can start playing")
      })

      audio.addEventListener("play", () => {
        console.log("Audio playback started")
        setIsPlaying(true)
      })

      audio.addEventListener("ended", () => {
        console.log("Audio playback ended")
        setIsPlaying(false)
        setAudioElement(null)
      })

      audio.addEventListener("error", (e) => {
        console.error("Audio playback error:", e)
        setIsPlaying(false)
        setAudioElement(null)
        setAudioError("Audio playback failed")
      })

      // Set audio source and play
      audio.src = audioUrl
      audio.load() // Explicitly load the audio
      setAudioElement(audio)

      // Play with user gesture (required by browsers)
      const playPromise = audio.play()
      if (playPromise !== undefined) {
        await playPromise
      }
    } catch (error) {
      console.error("Audio play error:", error)
      setIsPlaying(false)
      setAudioElement(null)
      setAudioError("Failed to play audio")
    }
  }

  // Stop ElevenLabs audio
  const stopElevenLabsAudio = () => {
    if (audioElement) {
      audioElement.pause()
      audioElement.currentTime = 0
      setAudioElement(null)
    }
    setIsPlaying(false)
  }

  // Cleanup useEffect
  useEffect(() => {
    return () => {
      // Cleanup: stop any playing speech when component unmounts
      if (currentUtterance) {
        window.speechSynthesis.cancel()
      }
      if (audioElement) {
        audioElement.pause()
      }
      if (audioUrl) {
        URL.revokeObjectURL(audioUrl)
      }
    }
  }, [])

  // Clear audio when roast changes
  useEffect(() => {
    return () => {
      // Stop any playing audio when roast changes
      if (audioElement) {
        audioElement.pause()
        setAudioElement(null)
      }
      if (audioUrl) {
        URL.revokeObjectURL(audioUrl)
      }
      setIsPlaying(false)
      setAudioError("")
    }
  }, [roast])

  const generateRoast = async () => {
    if (!selectedPerson) {
      console.error("No person selected")
      return
    }

    console.log("🔥 Starting roast generation...")
    setIsGenerating(true)
    setError("")
    setRoast("")
    setAudioError("")

    // Clear previous audio
    if (audioUrl) {
      URL.revokeObjectURL(audioUrl)
      setAudioUrl(null)
    }
    if (audioElement) {
      audioElement.pause()
      setAudioElement(null)
    }
    setIsPlaying(false)

    try {
      const requestBody = {
        personName: selectedPerson.name,
        personData: selectedPerson.whatsappData,
        images: selectedPerson.images || [],
        linkedinData: selectedPerson.linkedinData,
        linkedinUrl: selectedPerson.linkedinUrl,
        intensity: roastIntensity,
        type: roastType,
      }

      const response = await fetch("/api/generate-roast", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(requestBody),
      })

      const data = await response.json()

      if (data.success) {
        console.log("✅ Roast generated successfully!")
        setRoast(data.result)
        // Audio will be auto-generated by useEffect
      } else {
        throw new Error(data.error || "Generation failed")
      }
    } catch (error) {
      console.error("💥 Generation error:", error)
      setError(error instanceof Error ? error.message : "Failed to generate roast. Please try again!")
    } finally {
      setIsGenerating(false)
    }
  }

  const copyToClipboard = async () => {
    try {
      await navigator.clipboard.writeText(roast)
      console.log("📋 Copied to clipboard")
    } catch (error) {
      console.error("Copy failed:", error)
    }
  }

  const playRoastAudio = () => {
    if (!speechSupported || !roast) return

    // Stop any currently playing speech
    if (currentUtterance) {
      window.speechSynthesis.cancel()
      setCurrentUtterance(null)
      setIsPlaying(false)
      return
    }

    // Stop ElevenLabs audio if playing
    if (audioElement) {
      stopElevenLabsAudio()
    }

    const utterance = new SpeechSynthesisUtterance(roast)

    // Configure voice settings for maximum sass
    utterance.rate = 0.9
    utterance.pitch = 1.1
    utterance.volume = 1.0

    // Try to find a sassy voice
    const voices = window.speechSynthesis.getVoices()
    const preferredVoice = voices.find(
      (voice) =>
        voice.name.toLowerCase().includes("samantha") ||
        voice.name.toLowerCase().includes("karen") ||
        voice.name.toLowerCase().includes("female") ||
        voice.lang.startsWith("en-"),
    )

    if (preferredVoice) {
      utterance.voice = preferredVoice
    }

    utterance.onstart = () => {
      setIsPlaying(true)
      setCurrentUtterance(utterance)
    }

    utterance.onend = () => {
      setIsPlaying(false)
      setCurrentUtterance(null)
    }

    utterance.onerror = () => {
      setIsPlaying(false)
      setCurrentUtterance(null)
      console.error("Speech synthesis error")
    }

    window.speechSynthesis.speak(utterance)
  }

  const stopRoastAudio = () => {
    if (currentUtterance) {
      window.speechSynthesis.cancel()
      setCurrentUtterance(null)
      setIsPlaying(false)
    }
  }

  const getIntensityInfo = (intensity: RoastIntensity) => {
    switch (intensity) {
      case "mild":
        return { emoji: "😊", color: "from-green-500 to-emerald-500", label: "Friendly Banter" }
      case "medium":
        return { emoji: "🔥", color: "from-orange-500 to-red-500", label: "Spicy Roast" }
      case "savage":
        return { emoji: "💀", color: "from-red-500 to-pink-500", label: "Absolutely Savage" }
    }
  }

  const getRoastTypeInfo = (type: RoastType) => {
    switch (type) {
      case "text":
        return { icon: MessageCircle, label: "Text-Based", description: "Roast based on chat + LinkedIn" }
      case "visual":
        return { icon: Camera, label: "Visual Roast", description: "Roast based on photos/selfies" }
      case "combined":
        return { icon: Zap, label: "Ultimate Roast", description: "Combine all available data" }
    }
  }

  const canGenerateRoast = () => {
    if (!selectedPerson) return false

    const hasTextData = !!(selectedPerson.whatsappData || selectedPerson.linkedinData || selectedPerson.linkedinUrl)
    const hasVisualData = !!(selectedPerson.images && selectedPerson.images.length > 0)

    switch (roastType) {
      case "text":
        return hasTextData
      case "visual":
        return hasVisualData
      case "combined":
        return hasTextData || hasVisualData
      default:
        return false
    }
  }

  const getDataSummary = (person: Person) => {
    const parts = []
    if (person.whatsappData) parts.push(`${person.whatsappData.length} chars`)
    if (person.images && person.images.length > 0)
      parts.push(`${person.images.length} photo${person.images.length !== 1 ? "s" : ""}`)
    if (person.linkedinData || person.linkedinUrl) parts.push("LinkedIn")
    return parts.join(" • ")
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex items-center gap-4 relative">
        <div className="absolute -top-4 -left-8 text-3xl wiggle">🔥</div>
        <Button
          onClick={onBack}
          variant="ghost"
          className="text-gray-400 hover:text-white hover:bg-gray-800/50 rounded-xl"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back
        </Button>
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-xl bg-gradient-to-r from-orange-500 to-red-500">
            <Zap className="w-5 h-5 text-white" />
          </div>
          <h1 className="text-3xl font-bold text-white">AI Roast Master</h1>
        </div>
        <div className="absolute -top-2 -right-4 text-2xl bounce-slow">😈</div>
      </div>

      {/* Person Manager with Image Upload */}
      <PersonManager people={people} setPeople={setPeople} showImageUpload={true} />

      {people.length > 0 && (
        <>
          {/* Person Selection */}
          <Card className="bg-gray-900/50 border-red-700/30 shadow-xl backdrop-blur-sm">
            <div className="absolute top-2 right-2 text-xl opacity-30">👹</div>
            <CardContent className="p-6">
              <h3 className="text-lg font-semibold text-white mb-4">Choose your victim 😈</h3>
              <div className="grid gap-3">
                {people.map((person) => (
                  <Button
                    key={person.id}
                    variant={selectedPerson?.id === person.id ? "default" : "outline"}
                    className={`p-4 h-auto justify-start rounded-xl transition-all duration-200 ${
                      selectedPerson?.id === person.id
                        ? "bg-orange-600 hover:bg-orange-700 text-white border-orange-500"
                        : "bg-gray-800/30 hover:bg-gray-700/50 text-gray-200 border-gray-600/50"
                    }`}
                    onClick={() => setSelectedPerson(person)}
                  >
                    <div className="flex items-center gap-3 w-full">
                      <img
                        src={person.avatar || "/placeholder.svg"}
                        alt={person.name}
                        className="w-8 h-8 rounded-full"
                      />
                      <div className="text-left flex-1">
                        <div className="font-medium">{person.name}</div>
                        <div className="text-xs opacity-70">{getDataSummary(person)}</div>
                      </div>
                      <div className="flex items-center gap-1">
                        {person.images && person.images.length > 0 && (
                          <div className="flex -space-x-1">
                            {person.images.slice(0, 2).map((imageUrl, index) => (
                              <img
                                key={index}
                                src={imageUrl || "/placeholder.svg"}
                                alt={`${person.name} ${index + 1}`}
                                className="w-6 h-6 rounded-full border border-gray-600 object-cover"
                              />
                            ))}
                          </div>
                        )}
                        {(person.linkedinData || person.linkedinUrl) && <Briefcase className="w-4 h-4 text-blue-400" />}
                      </div>
                    </div>
                  </Button>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Roast Type Selection */}
          {selectedPerson && (
            <Card className="bg-gray-900/50 border-gray-700/30 shadow-xl backdrop-blur-sm">
              <CardContent className="p-6">
                <h3 className="text-lg font-semibold text-white mb-4">Choose roast type</h3>
                <div className="grid md:grid-cols-3 gap-4">
                  {(["text", "visual", "combined"] as RoastType[]).map((type) => {
                    const info = getRoastTypeInfo(type)
                    const Icon = info.icon

                    const hasTextData = !!(
                      selectedPerson.whatsappData ||
                      selectedPerson.linkedinData ||
                      selectedPerson.linkedinUrl
                    )
                    const hasVisualData = !!(selectedPerson.images && selectedPerson.images.length > 0)

                    const isAvailable =
                      type === "text" ? hasTextData : type === "visual" ? hasVisualData : hasTextData || hasVisualData

                    return (
                      <Button
                        key={type}
                        variant={roastType === type ? "default" : "outline"}
                        disabled={!isAvailable}
                        className={`p-4 h-auto rounded-xl transition-all duration-200 ${
                          roastType === type
                            ? "bg-gradient-to-r from-orange-600 to-red-600 text-white border-transparent"
                            : isAvailable
                              ? "bg-gray-800/30 hover:bg-gray-700/50 text-gray-200 border-gray-600/50"
                              : "bg-gray-900/50 text-gray-500 border-gray-700/30 cursor-not-allowed"
                        }`}
                        onClick={() => isAvailable && setRoastType(type)}
                      >
                        <div className="text-center">
                          <Icon className="w-6 h-6 mx-auto mb-2" />
                          <div className="font-medium">{info.label}</div>
                          <div className="text-xs opacity-70 mt-1">{info.description}</div>
                          {!isAvailable && (
                            <div className="text-xs text-gray-500 mt-1">
                              {type === "text" && "No text/LinkedIn data"}
                              {type === "visual" && "No photos"}
                              {type === "combined" && "Need some data"}
                            </div>
                          )}
                        </div>
                      </Button>
                    )
                  })}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Roast Intensity */}
          {selectedPerson && (
            <Card className="bg-gray-900/50 border-gray-700/30 shadow-xl backdrop-blur-sm">
              <CardContent className="p-6">
                <h3 className="text-lg font-semibold text-white mb-4">Choose your roast level</h3>
                <div className="grid md:grid-cols-3 gap-4">
                  {(["mild", "medium", "savage"] as RoastIntensity[]).map((intensity) => {
                    const info = getIntensityInfo(intensity)
                    return (
                      <Button
                        key={intensity}
                        variant={roastIntensity === intensity ? "default" : "outline"}
                        className={`p-4 h-auto rounded-xl transition-all duration-200 ${
                          roastIntensity === intensity
                            ? `bg-gradient-to-r ${info.color} text-white border-transparent`
                            : "bg-gray-800/30 hover:bg-gray-700/50 text-gray-200 border-gray-600/50"
                        }`}
                        onClick={() => set_roastIntensity(intensity)}
                      >
                        <div className="text-center">
                          <div className="text-2xl mb-2">{info.emoji}</div>
                          <div className="font-medium capitalize">{intensity}</div>
                          <div className="text-xs opacity-70">{info.label}</div>
                        </div>
                      </Button>
                    )
                  })}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Generation */}
          {selectedPerson && (
            <Card className="bg-gradient-to-br from-gray-900/70 to-gray-800/70 shadow-xl backdrop-blur-sm">
              <CardContent className="p-8 bg-zinc-950 border-none border-gray-400 border-8">
                <div className="text-center space-y-6">
                  <div className="flex items-center justify-center gap-3">
                    <img
                      src={selectedPerson.avatar || "/placeholder.svg"}
                      alt={selectedPerson.name}
                      className="w-12 h-12 rounded-full ring-2 ring-orange-500"
                    />
                    <h3 className="text-xl font-semibold text-white">
                      Roasting {selectedPerson.name} ({roastIntensity} {roastType})
                    </h3>
                    <div className="text-xl">🔥</div>
                  </div>

                  {/* Data Preview */}
                  <div className="flex justify-center gap-4 flex-wrap">
                    {roastType !== "text" && selectedPerson.images && selectedPerson.images.length > 0 && (
                      <div className="flex gap-2">
                        {selectedPerson.images.slice(0, 4).map((imageUrl, index) => (
                          <img
                            key={index}
                            src={imageUrl || "/placeholder.svg"}
                            alt={`${selectedPerson.name} ${index + 1}`}
                            className="w-12 h-12 rounded-lg object-cover border-2 border-orange-400/50"
                          />
                        ))}
                        {selectedPerson.images.length > 4 && (
                          <div className="w-12 h-12 rounded-lg bg-gray-800/50 border-2 border-orange-400/50 flex items-center justify-center text-xs text-orange-300">
                            +{selectedPerson.images.length - 4}
                          </div>
                        )}
                      </div>
                    )}

                    {(selectedPerson.linkedinData || selectedPerson.linkedinUrl) && (
                      <div className="flex items-center gap-2 bg-blue-900/30 border border-blue-500/30 rounded-lg px-3 py-2">
                        <Briefcase className="w-4 h-4 text-blue-400" />
                        <span className="text-sm text-blue-300">LinkedIn Data</span>
                      </div>
                    )}
                  </div>

                  <Button
                    onClick={generateRoast}
                    disabled={isGenerating || !canGenerateRoast()}
                    className="bg-gradient-to-r from-orange-600 to-red-600 hover:from-orange-700 hover:to-red-700 text-white h-12 px-8 rounded-xl font-medium disabled:opacity-50"
                  >
                    {isGenerating ? (
                      <div className="flex items-center gap-2">
                        <Loader2 className="w-4 h-4 animate-spin" />
                        Cooking up a roast...
                      </div>
                    ) : (
                      <>
                        <Flame className="w-4 h-4 mr-2" />
                        Generate Roast
                      </>
                    )}
                  </Button>

                  {/* Error Display */}
                  {error && (
                    <Card className="bg-red-900/40 border-red-500/50">
                      <CardContent className="p-4">
                        <div className="flex items-center gap-2 text-red-200">
                          <AlertCircle className="w-4 h-4" />
                          <span className="text-sm">{error}</span>
                        </div>
                      </CardContent>
                    </Card>
                  )}

                  {/* Roast Display */}
                  {roast && (
                    <div className="space-y-6">
                      <Card className="bg-gradient-to-br from-orange-900/40 to-red-900/40 border-orange-400/50 shadow-2xl relative overflow-hidden backdrop-blur-sm">
                        <div className="absolute -top-3 -right-3 text-2xl animate-bounce">💥</div>
                        <div className="absolute top-4 left-4 text-xl opacity-30">🔥</div>
                        <CardContent className="p-8 bg-red-600">
                          <div className="text-center space-y-4">
                            <div className="flex items-center justify-center gap-2 mb-4">
                              <div className="text-4xl animate-pulse">🔥</div>
                              <h4 className="text-2xl font-bold text-orange-200">ROASTED!</h4>
                              <div className="text-4xl animate-pulse">🔥</div>
                            </div>

                            <div className="bg-black/30 rounded-2xl p-6 border border-orange-500/30 shadow-inner">
                              <p className="text-white text-lg leading-relaxed font-medium italic">"{roast}"</p>
                            </div>

                            <div className="flex items-center justify-center gap-2 text-sm text-orange-300 mt-4">
                              <CheckCircle className="w-4 h-4 text-white" />
                              <span className="text-white">
                                Generated by AI • {roastIntensity} intensity • {roastType} roast
                              </span>
                            </div>

                            {/* Audio Generation Status */}
                            {isGeneratingAudio && (
                              <div className="flex items-center justify-center gap-2 text-sm text-blue-300">
                                <Loader2 className="w-4 h-4 animate-spin" />
                                <span>Generating high-quality voice...</span>
                              </div>
                            )}

                            {audioError && (
                              <div className="flex items-center justify-center gap-2 text-sm text-yellow-300">
                                <AlertCircle className="w-4 h-4" />
                                <span>Voice generation failed - using browser fallback</span>
                              </div>
                            )}
                          </div>
                        </CardContent>
                      </Card>

                      <div className="flex gap-3 justify-center flex-wrap">
                        {/* ElevenLabs Voice Button (Primary) */}
                        <Button
                          onClick={isPlaying ? stopElevenLabsAudio : playElevenLabsAudio}
                          disabled={isGeneratingAudio}
                          className={`${
                            isPlaying
                              ? "bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
                              : "bg-gradient-to-r from-green-600 to-blue-600 hover:from-green-700 hover:to-blue-700"
                          } text-white rounded-xl`}
                        >
                          {isPlaying ? (
                            <>
                              <Pause className="w-4 h-4 mr-2" />
                              Stop Roast
                            </>
                          ) : (
                            <>
                              <Volume2 className="w-4 h-4 mr-2" />
                              {audioUrl ? "Play Roast" : isGeneratingAudio ? "Generating..." : "Play Roast"}
                            </>
                          )}
                        </Button>

                        {/* Fallback Browser TTS Button */}
                        {speechSupported && (
                          <Button
                            onClick={isPlaying ? stopRoastAudio : playRoastAudio}
                            variant="outline"
                            className="border-purple-500/50 text-purple-300 hover:bg-purple-900/30 rounded-xl"
                            disabled={isGeneratingAudio}
                          >
                            <Volume2 className="w-4 h-4 mr-2" />
                            Browser Voice
                          </Button>
                        )}

                        {/* Retry Audio Generation */}
                        {audioError && (
                          <Button
                            onClick={generateElevenLabsAudio}
                            variant="outline"
                            className="border-blue-500/50 text-blue-300 hover:bg-blue-900/30 rounded-xl"
                            disabled={isGeneratingAudio}
                          >
                            <Loader2 className={`w-4 h-4 mr-2 ${isGeneratingAudio ? "animate-spin" : ""}`} />
                            Retry Voice
                          </Button>
                        )}

                        {/* Other buttons */}
                        <Button
                          onClick={generateRoast}
                          variant="outline"
                          className="border-red-500/50 hover:bg-red-900/30 rounded-xl text-red-600"
                          disabled={isGenerating}
                        >
                          <Flame className="w-4 h-4 mr-2" />
                          Another Roast
                        </Button>
                        <Button
                          onClick={copyToClipboard}
                          variant="outline"
                          className="border-orange-500/50 hover:bg-orange-900/30 rounded-xl text-orange-500"
                        >
                          <Copy className="w-4 h-4 mr-2" />
                          Copy
                        </Button>
                        <Button
                          variant="outline"
                          className="border-gray-500/50 hover:bg-gray-800/30 rounded-xl text-gray-600"
                          onClick={() => {
                            if (navigator.share) {
                              navigator
                                .share({
                                  title: `${selectedPerson?.name} got roasted!`,
                                  text: roast,
                                })
                                .catch(console.error)
                            } else {
                              copyToClipboard()
                            }
                          }}
                        >
                          <Share className="w-4 h-4 mr-2" />
                          Share
                        </Button>
                      </div>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          )}
        </>
      )}
    </div>
  )
}
