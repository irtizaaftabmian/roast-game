"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Copy, Crown, Users, Play, UserPlus } from "lucide-react"
import type { GameRoom } from "@/app/page"

interface RoomLobbyProps {
  room: GameRoom
  playerId: string
  isHost: boolean
  onStartSetup: () => void
}

export default function RoomLobby({ room, playerId, isHost, onStartSetup }: RoomLobbyProps) {
  const copyRoomCode = () => {
    navigator.clipboard.writeText(room.id)
    // You could add a toast notification here
  }

  const currentPlayer = room.players.find((p) => p.id === playerId)

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Room Info */}
      <Card className="bg-white/10 backdrop-blur-sm border-white/20">
        <CardHeader className="text-center">
          <CardTitle className="text-white flex items-center justify-center gap-2">
            <Users className="w-6 h-6" />
            Game Lobby
          </CardTitle>
          <div className="flex items-center justify-center gap-4 mt-4">
            <div className="flex items-center gap-2 bg-white/20 rounded-lg px-4 py-2">
              <span className="text-white font-mono text-xl">{room.id}</span>
              <Button
                variant="ghost"
                size="sm"
                onClick={copyRoomCode}
                className="text-purple-200 hover:text-white hover:bg-white/20"
              >
                <Copy className="w-4 h-4" />
              </Button>
            </div>
            <Badge className="bg-purple-600 text-white">
              {room.players.length} player{room.players.length !== 1 ? "s" : ""}
            </Badge>
          </div>
        </CardHeader>
      </Card>

      {/* Players List */}
      <Card className="bg-white/10 backdrop-blur-sm border-white/20">
        <CardHeader>
          <CardTitle className="text-white">Players in Room</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-2 gap-4">
            {room.players.map((player) => (
              <div
                key={player.id}
                className={`flex items-center gap-3 p-4 rounded-lg ${
                  player.id === playerId ? "bg-purple-600/30 border border-purple-400/50" : "bg-white/10"
                }`}
              >
                <img src={player.avatar || "/placeholder.svg"} alt={player.name} className="w-12 h-12 rounded-full" />
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <h3 className="text-white font-medium">{player.name}</h3>
                    {player.isHost && <Crown className="w-4 h-4 text-yellow-400" />}
                    {player.id === playerId && (
                      <Badge variant="secondary" className="bg-purple-600 text-white text-xs">
                        You
                      </Badge>
                    )}
                  </div>
                  <p className="text-purple-200 text-sm">
                    {player.whatsappData ? `${player.whatsappData.length} characters loaded` : "No data uploaded yet"}
                  </p>
                </div>
                <div className="text-right">
                  {player.whatsappData ? (
                    <Badge className="bg-green-600 text-white">Ready</Badge>
                  ) : (
                    <Badge variant="outline" className="border-yellow-400 text-yellow-400">
                      Waiting
                    </Badge>
                  )}
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Invite More Players */}
      <Card className="bg-white/10 backdrop-blur-sm border-white/20">
        <CardContent className="p-6 text-center">
          <UserPlus className="w-8 h-8 text-blue-400 mx-auto mb-3" />
          <h3 className="text-white text-lg font-medium mb-2">Invite More Friends</h3>
          <p className="text-purple-200 mb-4">
            Share the room code <span className="font-mono bg-white/20 px-2 py-1 rounded">{room.id}</span> with your
            friends
          </p>
          <Button onClick={copyRoomCode} variant="outline" className="border-white/30 text-white hover:bg-white/20">
            <Copy className="w-4 h-4 mr-2" />
            Copy Room Code
          </Button>
        </CardContent>
      </Card>

      {/* Game Controls */}
      {isHost && (
        <Card className="bg-white/10 backdrop-blur-sm border-white/20">
          <CardContent className="p-6 text-center">
            <h3 className="text-white text-lg font-medium mb-4">Host Controls</h3>

            {room.players.length >= 2 ? (
              <div className="space-y-4">
                <p className="text-green-200">✅ Ready to start! You have {room.players.length} players.</p>
                <Button
                  onClick={onStartSetup}
                  className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white text-lg px-8 py-3"
                >
                  <Play className="w-5 h-5 mr-2" />
                  Start Game Setup
                </Button>
              </div>
            ) : (
              <div className="space-y-4">
                <p className="text-yellow-200">⏳ Need at least 2 players to start the game</p>
                <p className="text-purple-200 text-sm">
                  Invite more friends to join with room code: <span className="font-mono">{room.id}</span>
                </p>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {!isHost && (
        <Card className="bg-white/10 backdrop-blur-sm border-white/20">
          <CardContent className="p-6 text-center">
            <Crown className="w-8 h-8 text-yellow-400 mx-auto mb-3" />
            <h3 className="text-white text-lg font-medium mb-2">Waiting for Host</h3>
            <p className="text-purple-200">The host will start the game when everyone is ready</p>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
