"use client"

import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { MessageCircle, Zap, ArrowRight } from "lucide-react"
import type { AppMode } from "@/app/page"

interface AppSelectorProps {
  onSelectApp: (mode: AppMode) => void
}

export default function AppSelector({ onSelectApp }: AppSelectorProps) {
  return (
    <div className="space-y-12">
      {/* Header with Troll */}
      <div className="text-center relative">
        <div className="absolute -top-4 -left-4 text-6xl wiggle">🧌</div>
        <div className="absolute -top-2 -right-8 text-4xl bounce-slow">😈</div>

        <div className="inline-flex items-center justify-center w-20 h-20 bg-green-gradient rounded-3xl mb-6 pulse-glow">
          <span className="text-3xl">🤪</span>
        </div>
        <h1 className="text-5xl font-bold bg-gradient-to-r from-green-400 via-emerald-300 to-green-200 bg-clip-text text-transparent mb-4">
          {"RoastFest"}
        </h1>
        <p className="text-xl text-gray-300 max-w-2xl mx-auto leading-relaxed">
          Upload chat data and let AI either impersonate your friends or create epic roasts. Choose your adventure.
        </p>

        <div className="absolute -bottom-4 left-1/2 transform -translate-x-1/2 text-3xl">👹</div>
      </div>

      {/* App Selection */}
      <div className="grid md:grid-cols-2 gap-8">
        {/* Impersonator App */}
        <Card className="bg-gray-900/50 border-green-700/30 hover:bg-gray-800/60 transition-all duration-300 group cursor-pointer relative overflow-hidden shadow-xl backdrop-blur-sm">
          <div className="absolute top-2 right-2 text-2xl opacity-50 group-hover:opacity-100 transition-opacity">
            🎭
          </div>
          <CardContent className="p-8">
            <div className="text-center space-y-6">
              <div className="p-4 rounded-2xl bg-gradient-to-r from-green-500 to-emerald-500 w-fit mx-auto group-hover:scale-110 transition-transform duration-300">
                <MessageCircle className="w-8 h-8 text-white" />
              </div>

              <div>
                <h3 className="text-2xl font-bold text-white mb-3">AI Impersonator</h3>
                <p className="text-gray-300 leading-relaxed mb-6">
                  Upload your friends' chat data and watch AI perfectly mimic their texting style, personality, and
                  quirks.
                </p>
              </div>

              <div className="space-y-3 text-sm text-gray-400">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-green-400 rounded-full"></div>
                  <span>Mimics texting patterns</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-green-400 rounded-full"></div>
                  <span>Captures personality traits</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-green-400 rounded-full"></div>
                  <span>Interactive guessing game</span>
                </div>
              </div>

              <Button
                onClick={() => onSelectApp("impersonator")}
                className="w-full bg-green-gradient hover:bg-green-gradient-dark text-white h-12 rounded-xl font-medium group-hover:shadow-lg group-hover:shadow-green-500/25 transition-all duration-300"
              >
                Start Impersonating
                <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform duration-300" />
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Roasting App */}
        <Card className="bg-gray-900/50 border-red-700/30 hover:bg-gray-800/60 transition-all duration-300 group cursor-pointer relative overflow-hidden shadow-xl backdrop-blur-sm">
          <div className="absolute top-2 right-2 text-2xl opacity-50 group-hover:opacity-100 transition-opacity">
            🔥
          </div>
          <CardContent className="p-8">
            <div className="text-center space-y-6">
              <div className="p-4 rounded-2xl bg-gradient-to-r from-orange-500 to-red-500 w-fit mx-auto group-hover:scale-110 transition-transform duration-300">
                <Zap className="w-8 h-8 text-white" />
              </div>

              <div>
                <h3 className="text-2xl font-bold text-white mb-3">AI Roast Master</h3>
                <p className="text-gray-300 leading-relaxed mb-6">
                  Generate hilarious, personalized roasts based on your friends' chat history. Prepare for savage burns!
                </p>
              </div>

              <div className="space-y-3 text-sm text-gray-400">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-red-400 rounded-full"></div>
                  <span>Personalized roasts</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-red-400 rounded-full"></div>
                  <span>Savage but friendly burns</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-red-400 rounded-full"></div>
                  <span>Share-worthy content</span>
                </div>
              </div>

              <Button
                onClick={() => onSelectApp("roasting")}
                className="w-full bg-gradient-to-r from-orange-600 to-red-600 hover:from-orange-700 hover:to-red-700 text-white h-12 rounded-xl font-medium group-hover:shadow-lg group-hover:shadow-orange-500/25 transition-all duration-300"
              >
                Start Roasting
                <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform duration-300" />
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Features with Trolls */}
      <div className="text-center relative">
        <div className="absolute -top-6 left-8 text-3xl wiggle">🤡</div>
        <div className="absolute -top-4 right-12 text-2xl bounce-slow">😜</div>

        <Card className="bg-gray-900/30 border-gray-700/30 shadow-xl backdrop-blur-sm">
          <CardContent className="p-8">
            <h3 className="text-lg font-semibold text-white mb-4">How it works</h3>
            <div className="grid md:grid-cols-3 gap-6 text-sm text-gray-300">
              <div className="space-y-2 relative">
                <div className="absolute -top-2 -right-2 text-lg">📱</div>
                <div className="w-8 h-8 bg-green-600 rounded-full flex items-center justify-center mx-auto text-white font-bold">
                  1
                </div>
                <p>Upload WhatsApp chat exports or paste sample messages</p>
              </div>
              <div className="space-y-2 relative">
                <div className="absolute -top-2 -right-2 text-lg">🧠</div>
                <div className="w-8 h-8 bg-emerald-600 rounded-full flex items-center justify-center mx-auto text-white font-bold">
                  2
                </div>
                <p>AI analyzes texting patterns, vocabulary, and personality</p>
              </div>
              <div className="space-y-2 relative">
                <div className="absolute -top-2 -right-2 text-lg">🎯</div>
                <div className="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center mx-auto text-white font-bold">
                  3
                </div>
                <p>Generate impersonations or roasts with scary accuracy</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="absolute -bottom-6 left-1/2 transform -translate-x-1/2 text-4xl">🎪</div>
      </div>
    </div>
  )
}
