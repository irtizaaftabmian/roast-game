"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Trophy, Medal, Award, RotateCcw, Sparkles } from "lucide-react"
import type { Player } from "@/app/page"

interface LeaderboardProps {
  players: Player[]
  onResetGame: () => void
}

export default function Leaderboard({ players, onResetGame }: LeaderboardProps) {
  const sortedPlayers = [...players].sort((a, b) => b.score - a.score)

  const getPositionInfo = (position: number) => {
    switch (position) {
      case 0:
        return {
          icon: Trophy,
          title: "Champion",
          emoji: "👑",
          gradient: "from-yellow-400 to-orange-500",
          bgGradient: "from-yellow-500/20 to-orange-500/20",
          borderColor: "border-yellow-500/50",
        }
      case 1:
        return {
          icon: Medal,
          title: "Runner-up",
          emoji: "🥈",
          gradient: "from-gray-300 to-gray-500",
          bgGradient: "from-gray-400/20 to-gray-600/20",
          borderColor: "border-gray-500/50",
        }
      case 2:
        return {
          icon: Award,
          title: "Third Place",
          emoji: "🥉",
          gradient: "from-amber-500 to-amber-700",
          bgGradient: "from-amber-500/20 to-amber-700/20",
          borderColor: "border-amber-500/50",
        }
      default:
        return {
          icon: Sparkles,
          title: "Great Job",
          emoji: "✨",
          gradient: "from-purple-500 to-blue-500",
          bgGradient: "from-purple-500/10 to-blue-500/10",
          borderColor: "border-gray-700",
        }
    }
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <Card className="bg-gray-900/30 border-gray-800 backdrop-blur-xl">
        <CardContent className="p-12 text-center">
          <div className="text-6xl mb-6">🎉</div>
          <h1 className="text-4xl font-bold bg-gradient-to-r from-white to-gray-300 bg-clip-text text-transparent mb-4">
            Game Complete!
          </h1>
          <p className="text-xl text-gray-400">Here's how everyone performed</p>
        </CardContent>
      </Card>

      {/* Leaderboard */}
      <div className="space-y-4">
        {sortedPlayers.map((player, index) => {
          const positionInfo = getPositionInfo(index)
          const Icon = positionInfo.icon

          return (
            <Card
              key={player.id}
              className={`bg-gradient-to-r ${positionInfo.bgGradient} border ${positionInfo.borderColor} backdrop-blur-xl ${
                index === 0 ? "ring-2 ring-yellow-500/50 shadow-lg shadow-yellow-500/20" : ""
              }`}
            >
              <CardContent className="p-8">
                <div className="flex items-center gap-6">
                  <div className={`p-4 rounded-2xl bg-gradient-to-r ${positionInfo.gradient}`}>
                    <Icon className="w-8 h-8 text-white" />
                  </div>

                  <img
                    src={player.avatar || "/placeholder.svg"}
                    alt={player.name}
                    className={`w-16 h-16 rounded-full ${
                      index === 0 ? "ring-4 ring-yellow-500" : "ring-2 ring-gray-600"
                    }`}
                  />

                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <h3 className={`text-2xl font-bold ${index === 0 ? "text-yellow-400" : "text-white"}`}>
                        {player.name}
                      </h3>
                      <span className="text-2xl">{positionInfo.emoji}</span>
                    </div>
                    <p className={`font-medium ${index === 0 ? "text-yellow-200" : "text-gray-300"}`}>
                      {positionInfo.title}
                    </p>
                  </div>

                  <div className="text-right">
                    <div
                      className={`text-3xl font-bold mb-1 ${
                        index === 0 ? "text-yellow-400" : index === 1 ? "text-gray-300" : "text-white"
                      }`}
                    >
                      {player.score}
                    </div>
                    <div className="text-gray-400 text-sm">points</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          )
        })}
      </div>

      {/* Play Again */}
      <Card className="bg-gray-900/30 border-gray-800 backdrop-blur-xl">
        <CardContent className="p-8 text-center">
          <h3 className="text-xl font-semibold text-white mb-4">Thanks for playing!</h3>
          <p className="text-gray-400 mb-8 max-w-md mx-auto">
            Hope you enjoyed discovering how well AI can capture your friends' personalities! 😄
          </p>
          <Button
            onClick={onResetGame}
            className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white h-14 px-8 rounded-2xl font-semibold text-lg transition-all duration-200"
          >
            <RotateCcw className="w-5 h-5 mr-3" />
            Play Again
          </Button>
        </CardContent>
      </Card>
    </div>
  )
}
