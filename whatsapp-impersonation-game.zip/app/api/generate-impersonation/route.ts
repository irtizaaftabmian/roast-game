import { type NextRequest, NextResponse } from "next/server"
import { generateText } from "ai"
import { xai } from "@ai-sdk/xai"

export async function POST(request: NextRequest) {
  try {
    const { personName, personData, type = "impersonation" } = await request.json()

    if (!personName || !personData) {
      return NextResponse.json({ error: "Person name and data are required" }, { status: 400 })
    }

    let prompt = ""

    if (type === "impersonation") {
      prompt = `Based on these WhatsApp messages from ${personName}, generate a realistic message that sounds exactly like their texting style, personality, and way of speaking:

Messages from ${personName}:
${personData}

Generate a single casual message that ${personName} might send in a group chat. Match their:
- Vocabulary and slang
- Emoji usage patterns  
- Sentence structure
- Personality traits
- Humor style
- Topics they typically discuss

Make it sound authentic and natural, as if ${personName} actually wrote it.`
    } else if (type === "roast") {
      prompt = `Based on these WhatsApp messages from ${personName}, create a playful roast about their texting habits and personality:

Messages from ${personName}:
${personData}

Generate a funny, lighthearted roast that calls out their texting style, personality quirks, or habits in a friendly way. Keep it humorous but not mean-spirited.`
    }

    const { text } = await generateText({
      model: xai("grok-beta"),
      prompt,
      maxTokens: 150,
      temperature: 0.8,
    })

    return NextResponse.json({
      success: true,
      result: text.trim(),
    })
  } catch (error) {
    console.error("Generation error:", error)

    // Fallback responses if AI fails
    const fallbackResponses = {
      impersonation: [
        `OMG you guys won't believe what just happened to me today 😭`,
        `Anyone else think pineapple on pizza is actually fire? Don't @ me lol 🍕`,
        `Just binged that new series and now I don't know what to do with my life...`,
        `Why do I always pick the slowest line at literally every store? 🙄`,
        `Coffee or tea? This will determine if we can be friends or not 😂`,
      ],
      roast: [
        `${request.json().then((data) => data.personName)} texts like they're writing a formal email to their grandma... but make it casual 💀`,
        `Not them using 47 emojis to say "ok" 😭`,
        `Their autocorrect has given up trying to fix their spelling at this point`,
        `The way they leave people on read but then post on their story... iconic behavior honestly`,
      ],
    }

    const type = (await request.json()).type || "impersonation"
    const responses = fallbackResponses[type as keyof typeof fallbackResponses]
    const randomResponse = responses[Math.floor(Math.random() * responses.length)]

    return NextResponse.json({
      success: true,
      result: randomResponse,
    })
  }
}
