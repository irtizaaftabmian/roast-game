import { type NextRequest, NextResponse } from "next/server"
import { generateText } from "ai"
import { openai } from "@ai-sdk/openai"

export async function POST(req: NextRequest) {
  try {
    const { playerData, mode, playerName } = await req.json()

    let prompt = ""

    switch (mode) {
      case "question":
        prompt = `Based on this person's WhatsApp messages, generate a casual question or statement they might ask in a group chat. Make it sound exactly like their texting style:

Messages: ${playerData}

Generate a single message that sounds like ${playerName} would write it. Include their typical expressions, emoji usage, and tone.`
        break

      case "roast":
        prompt = `Based on this person's WhatsApp messages, generate a playful roast or sarcastic comment they might make. Keep it friendly but witty:

Messages: ${playerData}

Generate a single roasting comment that sounds like ${playerName}'s style of humor and sarcasm.`
        break

      case "voice":
        prompt = `Based on this person's WhatsApp messages, describe how they would say something in their typical speaking style:

Messages: ${playerData}

Generate a voice impersonation description like "*In their excited voice* [quote]" that captures ${playerName}'s speaking patterns.`
        break
    }

    const { text } = await generateText({
      model: openai("gpt-4o"),
      prompt,
      maxTokens: 150,
    })

    return NextResponse.json({ response: text })
  } catch (error) {
    console.error("Error generating impersonation:", error)
    return NextResponse.json({ error: "Failed to generate impersonation" }, { status: 500 })
  }
}
