import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const { fileUrl, personName } = await request.json()

    if (!fileUrl) {
      return NextResponse.json({ error: "File URL is required" }, { status: 400 })
    }

    // Fetch the file content from blob storage
    const response = await fetch(fileUrl)
    const content = await response.text()

    // Process WhatsApp chat export
    const processedData = processWhatsAppData(content, personName)

    return NextResponse.json({
      success: true,
      data: processedData,
      characterCount: processedData.length,
    })
  } catch (error) {
    console.error("Processing error:", error)
    return NextResponse.json({ error: "Failed to process chat data" }, { status: 500 })
  }
}

function processWhatsAppData(content: string, personName: string): string {
  // Basic WhatsApp chat parsing
  const lines = content.split("\n")
  const personMessages: string[] = []

  for (const line of lines) {
    // Match WhatsApp format: [date, time] Contact Name: message
    const match = line.match(/\[(.*?)\] (.*?): (.*)/)
    if (match) {
      const [, , sender, message] = match

      // If personName is provided, filter for that person's messages
      if (!personName || sender.toLowerCase().includes(personName.toLowerCase())) {
        personMessages.push(message.trim())
      }
    }
  }

  // Return processed messages or original content if no matches
  return personMessages.length > 0 ? personMessages.join("\n") : content.slice(0, 2000)
}
