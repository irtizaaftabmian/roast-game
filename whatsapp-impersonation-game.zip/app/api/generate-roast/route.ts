import { type NextRequest, NextResponse } from "next/server"
import { generateText } from "ai"
import { xai } from "@ai-sdk/xai"
import { openai } from "@ai-sdk/openai"

export async function POST(request: NextRequest) {
  try {
    const {
      personName,
      personData,
      images = [],
      linkedinData,
      linkedinUrl,
      intensity = "medium",
      type = "combined",
      useOpenAI = false, // Add option to choose AI provider
    } = await request.json()

    console.log("Roast generation request:", {
      personName,
      type,
      intensity,
      imageCount: images.length,
      hasLinkedIn: !!(linkedinData || linkedinUrl),
      provider: useOpenAI ? "OpenAI" : "xAI",
    })

    if (!personName) {
      return NextResponse.json({ error: "Person name is required" }, { status: 400 })
    }

    // Validate that we have the required data for the roast type
    const hasTextData = !!(personData || linkedinData)
    const hasVisualData = !!(images && images.length > 0)

    if (type === "text" && !hasTextData) {
      return NextResponse.json({ error: "Chat or LinkedIn data is required for text-based roasts" }, { status: 400 })
    }
    if (type === "visual" && !hasVisualData) {
      return NextResponse.json({ error: "Images are required for visual roasts" }, { status: 400 })
    }
    if (type === "combined" && !hasTextData && !hasVisualData) {
      return NextResponse.json({ error: "At least chat data, LinkedIn data, or images are required" }, { status: 400 })
    }

    let systemPrompt = `You are a witty AI roast master. Generate clever, humorous roasts that are playful but not cruel. Keep it entertaining and lighthearted. Focus on observable details and be creative with your observations.`

    // Adjust system prompt based on intensity
    switch (intensity) {
      case "mild":
        systemPrompt += ` Write a comprehensive roast with high-energy, animated humor. Start the roast directly with no intro, diving straight into the insults. Deliver 20-25 unique, playful bullet-point insults, each being 1-2 sentences long, poking fun at their unoriginal content, weak fame game, and try-hard attitude with loud, animated humor—think wild facial expressions and "you serious?!" vibes. Keep it light and funny, like teasing a friend. Format each bullet point on its own line with proper spacing for easy reading.`
        break
      case "medium":
        systemPrompt += ` Write a comprehensive roast with chaotic comedy energy. Start the roast directly with no intro, diving straight into the insults. Deliver 20-25 unique, edgy bullet-point insults, each being 1-2 sentences long, clowning their garbage content, desperate attention grabs, and inflated ego with over-the-top, "who raised you?!" energy and absurd, biting humor. Keep it sharp but not fully ruthless. Format each bullet point on its own line with proper spacing for easy reading.`
        break
      case "savage":
        systemPrompt += ` Write a comprehensive roast with explosive, no-chill comedy energy. Start the roast directly with no intro, diving straight into the insults. Deliver 20-25 unique, merciless bullet-point insults, each being 1-2 sentences long, tearing into their embarrassing videos, nonexistent fame, and laughable ego with high-pitched, "you gotta be kiddin' me!" savagery and unapologetic roast energy. Go full scorched-earth mode. Format each bullet point on its own line with proper spacing for easy reading.`
        break
    }

    let prompt = ""

    // Build comprehensive data context
    let dataContext = ""
    if (personData) {
      dataContext += `WhatsApp Messages from ${personName}:\n${personData}\n\n`
    }
    if (linkedinData) {
      dataContext += `LinkedIn Profile Data for ${personName}:\n${linkedinData}\n\n`
    }
    if (linkedinUrl) {
      dataContext += `LinkedIn Profile URL: ${linkedinUrl}\n\n`
    }

    // Build prompt based on roast type
    if (type === "text") {
      prompt = `Based on this data about ${personName}, create a ${intensity} roast about their personality, professional life, and communication style:

${dataContext}

Generate a funny, ${intensity === "savage" ? "savage" : "lighthearted"} roast that cleverly combines insights from their messaging style${linkedinData ? " and professional background" : ""}. Make it witty and entertaining.`
    } else if (type === "visual") {
      prompt = `Look at ${images.length > 1 ? "these photos" : "this photo"} of ${personName}. Based on what you see, create a ${intensity} visual roast about their appearance, poses, expressions, facial features, clothing, background, or what's happening in the ${images.length > 1 ? "photos" : "photo"}.

Be observant and creative - comment on their style, expressions, poses, or anything funny you notice. Generate a ${intensity === "savage" ? "savage" : "lighthearted"} roast based on the visual content.`
    } else if (type === "combined") {
      if (images && images.length > 0) {
        prompt = `I have comprehensive data about ${personName} including ${images.length > 1 ? "photos" : "a photo"}${personData ? ", WhatsApp messages" : ""}${linkedinData ? ", and LinkedIn profile data" : ""}. Create a ${intensity} roast that combines insights from all available data.

${dataContext}

Look at their ${images.length > 1 ? "photos" : "photo"} and combine what you see with their personality and professional background. Generate a comprehensive roast that cleverly connects their visual appearance${personData ? ", messaging style" : ""}${linkedinData ? ", and professional persona" : ""}. Make it ${intensity === "savage" ? "absolutely savage" : "witty and entertaining"}.`
      } else {
        // Text-only combined roast
        prompt = `Based on this comprehensive data about ${personName}, create a ${intensity} roast that combines insights from their personality and professional life:

${dataContext}

Generate a roast that cleverly weaves together their${personData ? " messaging personality" : ""}${linkedinData ? " and professional background" : ""}. Make it ${intensity === "savage" ? "savage" : "witty and entertaining"}.`
      }
    }

    let result

    try {
      console.log(`Using ${useOpenAI ? "OpenAI" : "xAI"} model`)

      // Choose AI provider based on request
      if (useOpenAI && process.env.OPENAI_API_KEY) {
        result = await generateText({
          model: openai("gpt-4o"),
          system: systemPrompt,
          prompt: prompt,
          maxTokens: 500,
          temperature: 0.9,
        })
      } else {
        result = await generateText({
          model: xai("grok-3"),
          system: systemPrompt,
          prompt: prompt,
          maxTokens: 500,
          temperature: 0.9,
        })
      }

      console.log("AI generation successful")
      return NextResponse.json({
        success: true,
        result: result.text.trim(),
        provider: useOpenAI && process.env.OPENAI_API_KEY ? "OpenAI" : "xAI",
      })
    } catch (aiError) {
      console.error("AI generation failed:", aiError)

      // Enhanced fallback with LinkedIn context
      const fallbackRoasts = {
        text: {
          mild: [
            `${personName} texts like they're writing a formal email to their grandma... but make it casual 😅`,
            `Not ${personName} using 47 emojis to say "ok" 💀`,
            `${personName}'s autocorrect has given up trying to fix their spelling at this point`,
            ...(linkedinData
              ? [`${personName}'s LinkedIn says "thought leader" but their messages say "thought follower" 💼`]
              : []),
          ],
          medium: [
            `${personName} really said "let me leave everyone on read but still post on my story" - iconic behavior honestly 📱`,
            `The way ${personName} types "heyyyy" with different amounts of y's depending on how desperate they are... we see you 👀`,
            `${personName}'s texting style is giving "I learned English from TikTok comments" energy`,
            ...(linkedinData
              ? [
                  `${personName}'s LinkedIn bio says "results-driven" but their messages are more like "results-avoiding" 💀`,
                ]
              : []),
          ],
          savage: [
            `${personName} texts like they're having a stroke but somehow we all understand them perfectly - that's talent 💀`,
            `Not ${personName} thinking "k" is an appropriate response to a paragraph... the audacity is unmatched`,
            `${personName}'s messages look like they were typed during an earthquake while riding a roller coaster`,
            ...(linkedinData
              ? [
                  `${personName}'s LinkedIn says "innovative problem solver" but their biggest problem is forming coherent sentences 😭`,
                ]
              : []),
          ],
        },
        visual: {
          mild: [
            `${personName} really said "let me take 47 selfies and post the one where I look least like myself" 📸`,
            `The confidence in ${personName}'s poses is inspiring... misguided, but inspiring 😊`,
            `${personName}'s selfie game is so strong, they probably have a separate Instagram just for their mirror`,
          ],
          medium: [
            `${personName} poses like they're about to drop the hottest album of 2019... the delusion is real 🔥`,
            `Not ${personName} thinking that angle was it... bestie, the camera doesn't lie 📱`,
            `${personName}'s photo editing skills are so obvious, even my grandma would notice`,
          ],
          savage: [
            `${personName} really thought they did something with that pose, but the only thing they did was prove that confidence can't be bought 💀`,
            `The way ${personName} looks like they're about to ask for the manager of the entire internet... iconic 😭`,
            `${personName}'s photos have more filters than a water treatment plant`,
          ],
        },
        combined: {
          mild: [
            `${personName} texts like a poet but poses like they're selling something on Facebook Marketplace 😅`,
            `The disconnect between ${personName}'s confident messages and their awkward photos is sending me`,
            `${personName} really said "I'm mysterious" in their bio but their photos tell a completely different story`,
            ...(linkedinData
              ? [`${personName}'s LinkedIn says "professional" but their whole vibe says "professional disaster" 💼`]
              : []),
          ],
          medium: [
            `${personName}'s texts say "main character energy" but their photos say "background extra who wandered into frame" 📸`,
            `Not ${personName} being all philosophical in messages but looking like they're solving math problems in every photo 🤔`,
            `${personName} types like Shakespeare but poses like they're at a driver's license photo shoot`,
            ...(linkedinData
              ? [`${personName}'s LinkedIn screams "thought leader" but their photos whisper "thoughts unclear" 💭`]
              : []),
          ],
          savage: [
            `${personName} texts like they're the protagonist of life but their photos suggest they're more of a cautionary tale 💀`,
            `The contrast between ${personName}'s witty messages and their "deer in headlights" expression in photos is art`,
            `${personName} really said "I'm that girl" in texts but their photos are giving "I'm that girl's awkward cousin"`,
            ...(linkedinData
              ? [
                  `${personName}'s LinkedIn says "results-driven professional" but their photos are giving "professionally confused" 😭`,
                ]
              : []),
          ],
        },
      }

      const typeRoasts = fallbackRoasts[type as keyof typeof fallbackRoasts] || fallbackRoasts.combined
      const intensityRoasts = typeRoasts[intensity as keyof typeof typeRoasts] || typeRoasts.medium
      const randomRoast = intensityRoasts[Math.floor(Math.random() * intensityRoasts.length)]

      return NextResponse.json({
        success: true,
        result: randomRoast,
        fallback: true,
        provider: "fallback",
      })
    }
  } catch (error) {
    console.error("Generation error:", error)
    return NextResponse.json(
      {
        error: "Failed to generate roast",
        details: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}
