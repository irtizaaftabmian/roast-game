import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const { text, voiceId } = await request.json()

    if (!text || typeof text !== "string") {
      return NextResponse.json({ error: "Text is required" }, { status: 400 })
    }

    if (!process.env.ELEVENLABS_API_KEY) {
      return NextResponse.json({ error: "ElevenLabs API key not configured" }, { status: 500 })
    }

    // Use the voice ID from the curl example, or allow custom voice ID
    const selectedVoiceId = voiceId || "agent_01jycjz2ycfcxtkprdav9j8qks"

    console.log("🎤 Generating ElevenLabs TTS with voice:", selectedVoiceId)
    console.log("Text length:", text.length, "characters")

    // Use the standard text-to-speech endpoint with output format
    const response = await fetch(
      `https://api.elevenlabs.io/v1/text-to-speech/${selectedVoiceId}?output_format=mp3_44100_128`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "xi-api-key": process.env.ELEVENLABS_API_KEY,
        },
        body: JSON.stringify({
          text: text.trim(), // Clean the text
          model_id: "eleven_multilingual_v2",
          voice_settings: {
            stability: 0.5,
            similarity_boost: 0.8,
            style: 0.2,
            use_speaker_boost: true,
          },
        }),
      },
    )

    if (!response.ok) {
      const errorData = await response.text()
      console.error("ElevenLabs API error:", response.status, errorData)

      // Return a proper error response
      return NextResponse.json(
        {
          error: `ElevenLabs API error: ${response.status}`,
          details: errorData,
        },
        { status: response.status },
      )
    }

    // Verify we got audio content
    const contentType = response.headers.get("content-type") || ""
    if (!contentType.includes("audio") && !contentType.includes("mpeg")) {
      console.error("ElevenLabs returned non-audio content:", contentType)
      return NextResponse.json({ error: "ElevenLabs returned non-audio content" }, { status: 500 })
    }

    // Get the audio stream
    const audioBuffer = await response.arrayBuffer()

    if (audioBuffer.byteLength === 0) {
      console.error("ElevenLabs returned empty audio")
      return NextResponse.json({ error: "ElevenLabs returned empty audio" }, { status: 500 })
    }

    console.log("✅ ElevenLabs audio generated successfully, size:", audioBuffer.byteLength, "bytes")

    // Return the audio as MP3 with proper headers
    return new Response(audioBuffer, {
      status: 200,
      headers: {
        "Content-Type": "audio/mpeg",
        "Content-Length": audioBuffer.byteLength.toString(),
        "Accept-Ranges": "bytes",
        "Cache-Control": "public, max-age=3600",
        // CORS headers for cross-origin requests
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "POST, OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type",
      },
    })
  } catch (error) {
    console.error("ElevenLabs TTS error:", error)
    return NextResponse.json(
      {
        error: "Failed to generate speech",
        details: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}

// Handle OPTIONS requests for CORS
export async function OPTIONS() {
  return new Response(null, {
    status: 200,
    headers: {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "POST, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type",
    },
  })
}
