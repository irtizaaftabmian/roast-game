import { type NextRequest, NextResponse } from "next/server"
import type { GameRoom, Player } from "@/app/page"
import { rooms } from "@/lib/room-store"

function generateRoomId(): string {
  const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
  let result = ""
  for (let i = 0; i < 6; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length))
  }
  return result
}

function generatePlayerId(): string {
  return Math.random().toString(36).substring(2, 15)
}

export async function POST(req: NextRequest) {
  try {
    const { hostName } = await req.json()

    const roomId = generateRoomId()
    const playerId = generatePlayerId()

    const host: Player = {
      id: playerId,
      name: hostName,
      whatsappData: "",
      avatar: `https://api.dicebear.com/7.x/avataaars/svg?seed=${hostName}`,
      score: 0,
      isHost: true,
    }

    const room: GameRoom = {
      id: roomId,
      players: [host],
      gameState: "lobby",
      currentRound: 0,
      hostId: playerId,
    }

    rooms.set(roomId, room)

    return NextResponse.json({
      success: true,
      roomId,
      playerId,
    })
  } catch (error) {
    console.error("Error creating room:", error)
    return NextResponse.json({ error: "Failed to create room" }, { status: 500 })
  }
}
