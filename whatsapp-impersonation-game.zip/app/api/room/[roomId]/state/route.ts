import { type NextRequest, NextResponse } from "next/server"
import { rooms } from "@/lib/room-store"
import type { GameState } from "@/app/page"

export async function POST(req: NextRequest, { params }: { params: { roomId: string } }) {
  try {
    const { roomId } = params
    const { gameState, playerId } = await req.json()

    const room = rooms.get(roomId)
    if (!room) {
      return NextResponse.json({ error: "Room not found" }, { status: 404 })
    }

    // Verify player is host
    if (room.hostId !== playerId) {
      return NextResponse.json({ error: "Only host can change game state" }, { status: 403 })
    }

    room.gameState = gameState as GameState
    rooms.set(roomId, room)

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Error updating game state:", error)
    return NextResponse.json({ error: "Failed to update game state" }, { status: 500 })
  }
}
