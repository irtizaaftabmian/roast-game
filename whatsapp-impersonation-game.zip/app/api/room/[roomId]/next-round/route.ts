import { type NextRequest, NextResponse } from "next/server"
import { rooms } from "@/lib/room-store"

export async function POST(req: NextRequest, { params }: { params: { roomId: string } }) {
  try {
    const { roomId } = params

    const room = rooms.get(roomId)
    if (!room) {
      return NextResponse.json({ error: "Room not found" }, { status: 404 })
    }

    room.currentRound += 1
    rooms.set(roomId, room)

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Error advancing round:", error)
    return NextResponse.json({ error: "Failed to advance round" }, { status: 500 })
  }
}
