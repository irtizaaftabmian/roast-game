import { type NextRequest, NextResponse } from "next/server"
import { rooms } from "@/lib/room-store"

export async function POST(req: NextRequest, { params }: { params: { roomId: string } }) {
  try {
    const { roomId } = params
    const { playerId, guess } = await req.json()

    const room = rooms.get(roomId)
    if (!room) {
      return NextResponse.json({ error: "Room not found" }, { status: 404 })
    }

    // Store player guess (in production, use proper state management)
    // This is a simplified approach for the demo

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Error submitting guess:", error)
    return NextResponse.json({ error: "Failed to submit guess" }, { status: 500 })
  }
}
