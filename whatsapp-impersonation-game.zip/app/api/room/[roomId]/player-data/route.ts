import { type NextRequest, NextResponse } from "next/server"
import { rooms } from "@/lib/room-store"

export async function POST(req: NextRequest, { params }: { params: { roomId: string } }) {
  try {
    const { roomId } = params
    const { playerId, whatsappData } = await req.json()

    const room = rooms.get(roomId)
    if (!room) {
      return NextResponse.json({ error: "Room not found" }, { status: 404 })
    }

    const playerIndex = room.players.findIndex((p) => p.id === playerId)
    if (playerIndex === -1) {
      return NextResponse.json({ error: "Player not found" }, { status: 404 })
    }

    room.players[playerIndex].whatsappData = whatsappData
    rooms.set(roomId, room)

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Error updating player data:", error)
    return NextResponse.json({ error: "Failed to update player data" }, { status: 500 })
  }
}
