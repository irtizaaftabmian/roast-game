import { type NextRequest, NextResponse } from "next/server"
import { rooms } from "@/lib/room-store"

export async function POST(req: NextRequest, { params }: { params: { roomId: string } }) {
  try {
    const { roomId } = params
    const { correctAnswer } = await req.json()

    const room = rooms.get(roomId)
    if (!room) {
      return NextResponse.json({ error: "Room not found" }, { status: 404 })
    }

    // Calculate scores (simplified for demo)
    // In production, track individual guesses and award points accordingly

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Error processing results:", error)
    return NextResponse.json({ error: "Failed to process results" }, { status: 500 })
  }
}
