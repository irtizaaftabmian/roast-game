import { type NextRequest, NextResponse } from "next/server"
import { rooms } from "@/lib/room-store"

export async function POST(req: NextRequest, { params }: { params: { roomId: string } }) {
  try {
    const { roomId } = params
    const body = await req.json()

    const room = rooms.get(roomId)
    if (!room) {
      return NextResponse.json({ error: "Room not found" }, { status: 404 })
    }

    // Store round data (in production, use proper state management)
    // This is a simplified approach for the demo

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Error updating round:", error)
    return NextResponse.json({ error: "Failed to update round" }, { status: 500 })
  }
}
