import type { NextRequest } from "next/server"
import { rooms } from "@/lib/room-store"

export async function GET(req: NextRequest, { params }: { params: { roomId: string } }) {
  const { roomId } = params
  const playerId = req.nextUrl.searchParams.get("playerId")

  if (!playerId) {
    return new Response("Player ID required", { status: 400 })
  }

  const room = rooms.get(roomId)
  if (!room) {
    return new Response("Room not found", { status: 404 })
  }

  // Set up Server-Sent Events
  const encoder = new TextEncoder()

  const stream = new ReadableStream({
    start(controller) {
      // Send initial room state
      const data = JSON.stringify({
        type: "room-update",
        room,
      })
      controller.enqueue(encoder.encode(`data: ${data}\n\n`))

      // Set up periodic updates (in production, use proper event system)
      const interval = setInterval(() => {
        const currentRoom = rooms.get(roomId)
        if (currentRoom) {
          const data = JSON.stringify({
            type: "room-update",
            room: currentRoom,
          })
          controller.enqueue(encoder.encode(`data: ${data}\n\n`))
        }
      }, 1000)

      // Clean up on close
      req.signal.addEventListener("abort", () => {
        clearInterval(interval)
        controller.close()
      })
    },
  })

  return new Response(stream, {
    headers: {
      "Content-Type": "text/event-stream",
      "Cache-Control": "no-cache",
      Connection: "keep-alive",
    },
  })
}
