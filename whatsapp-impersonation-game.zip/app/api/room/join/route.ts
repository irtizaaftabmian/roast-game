import { type NextRequest, NextResponse } from "next/server"
import { rooms } from "@/lib/room-store"
import type { Player } from "@/app/page"

function generatePlayerId(): string {
  return Math.random().toString(36).substring(2, 15)
}

export async function POST(req: NextRequest) {
  try {
    const { roomId, playerName } = await req.json()

    const room = rooms.get(roomId)
    if (!room) {
      return NextResponse.json({ error: "Room not found" }, { status: 404 })
    }

    // Check if player name already exists
    if (room.players.some((p) => p.name.toLowerCase() === playerName.toLowerCase())) {
      return NextResponse.json({ error: "Player name already taken" }, { status: 400 })
    }

    const playerId = generatePlayerId()
    const newPlayer: Player = {
      id: playerId,
      name: playerName,
      whatsappData: "",
      avatar: `https://api.dicebear.com/7.x/avataaars/svg?seed=${playerName}`,
      score: 0,
      isHost: false,
    }

    room.players.push(newPlayer)
    rooms.set(roomId, room)

    return NextResponse.json({
      success: true,
      playerId,
    })
  } catch (error) {
    console.error("Error joining room:", error)
    return NextResponse.json({ error: "Failed to join room" }, { status: 500 })
  }
}
