"use client"

import { useState } from "react"
import AppSelector from "@/components/app-selector"
import ImpersonatorApp from "@/components/impersonator-app"
import RoastingApp from "@/components/roasting-app"

export type AppMode = "selector" | "impersonator" | "roasting"

export type Person = {
  id: string
  name: string
  whatsappData: string
  avatar: string
  images?: string[] // Add images array for roasting
  linkedinUrl?: string // LinkedIn profile URL
  linkedinData?: string // LinkedIn profile/resume data
}

export default function Home() {
  const [appMode, setAppMode] = useState<AppMode>("selector")
  const [people, setPeople] = useState<Person[]>([])

  const resetToSelector = () => {
    setAppMode("selector")
    setPeople([])
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-950 via-black to-gray-900 text-white">
      <div className="max-w-4xl mx-auto px-6 py-12">
        {appMode === "selector" && <AppSelector onSelectApp={setAppMode} />}

        {appMode === "impersonator" && (
          <ImpersonatorApp people={people} setPeople={setPeople} onBack={resetToSelector} />
        )}

        {appMode === "roasting" && <RoastingApp people={people} setPeople={setPeople} onBack={resetToSelector} />}
      </div>
    </div>
  )
}
