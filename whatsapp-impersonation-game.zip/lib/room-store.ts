// A single source of truth for all game rooms.
// Using a global variable guarantees the store
// survives hot-reloads in development *and* is shared
// across every route handler in the same process.

import type { GameRoom } from "@/app/page"

declare global {
  // eslint-disable-next-line no-var
  var __ROOMS_STORE__: Map<string, GameRoom> | undefined
}

export const rooms: Map<string, GameRoom> = global.__ROOMS_STORE__ ?? (global.__ROOMS_STORE__ = new Map())
